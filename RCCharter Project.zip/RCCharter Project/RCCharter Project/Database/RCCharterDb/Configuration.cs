﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace RCCharterDb
{
    public class Configuration
    {
        public class CustomerConfigurations : IEntityTypeConfiguration<Customer>
        {
            public void Configure(EntityTypeBuilder<Customer> builder)
            {
                builder.ToTable(nameof(Customer));
                builder.HasKey(c => c.CustomerId);
                builder.Property(c => c.CustomerName);
                builder.Property(c => c.HasCreditAuthorization);
                builder
                    .HasOne(c => c.AccountLink)
                    .WithOne(c => c.CustomerLink);
                builder
                    .HasMany(c => c.Reservations)
                    .WithOne(c => c.CustomerLink)
                    .HasForeignKey(c => c.CustomerId)
                    .OnDelete(DeleteBehavior.Cascade);
                builder
                    .HasMany(c => c.Billings)
                    .WithOne(c => c.CustomerLink)
                    .HasForeignKey(c => c.CustomerId)
                    .OnDelete(DeleteBehavior.Cascade);

            }
        }
        public class AircraftConfigurations : IEntityTypeConfiguration<Aircraft>
        {
            public void Configure(EntityTypeBuilder<Aircraft> builder)
            {
                builder.ToTable(nameof(Aircraft));
                builder.HasKey(c => c.AircraftId);
                builder.Property(c => c.Model);
                builder.Property(c => c.TakeoffWeight);
                builder.Property(c => c.WaitingCharge);
                builder
                    .HasMany(c => c.ReservationList)
                    .WithOne(c => c.AircraftLink)
                    .HasForeignKey(c => c.AircraftId)
                    .OnDelete(DeleteBehavior.SetNull);
            }
        }
        public class AccountConfigurations : IEntityTypeConfiguration<Account>
        {
            public void Configure(EntityTypeBuilder<Account> builder)
            {
                builder.ToTable(nameof(Account));
                builder.HasKey(c => c.AccountId);
                builder.Property(c => c.AccountBalance);
                builder.Property(c => c.PartialPayable);
                builder
                    .HasOne(c => c.CustomerLink)
                    .WithOne(c => c.AccountLink)
                    .HasForeignKey<Account>(c => c.CustomerId)
                    .OnDelete(DeleteBehavior.SetNull);
                builder
                    .HasMany(c => c.Billings)
                    .WithOne(c => c.AccountLink)
                    .HasForeignKey(c => c.AccountId)
                    .OnDelete(DeleteBehavior.SetNull);

            }
        }
        public class CrewConfigurations : IEntityTypeConfiguration<Crew>
        {
            public void Configure(EntityTypeBuilder<Crew> builder)
            {
                builder.ToTable(nameof(Crew));
                builder.HasKey(c => c.CrewId);
                builder.Property(c => c.CrewName);
                builder
                    .HasMany(c => c.CrewLicenseList)
                    .WithOne(c => c.CrewLink)
                    .HasForeignKey(c => c.CrewId)
                    .OnDelete(DeleteBehavior.Cascade);
                builder
                    .HasMany(c => c.CrewTestList)
                    .WithOne(c => c.CrewLink)
                    .HasForeignKey(c => c.CrewId)
                    .OnDelete(DeleteBehavior.Cascade);
                builder
                    .HasMany(c => c.CrewTrainingList)
                    .WithOne(c => c.CrewLink)
                    .HasForeignKey(c => c.CrewId)
                    .OnDelete(DeleteBehavior.Cascade);
            }
        }
        public class TestConfigurations : IEntityTypeConfiguration<Test>
        {
            public void Configure(EntityTypeBuilder<Test> builder)
            {
                builder.ToTable(nameof(Test));
                builder.HasKey(c => c.TestId);
                builder.Property(c => c.TestDescription);
                builder.Property(c => c.TestFrequency);
                builder
                    .HasMany(c => c.CrewTestList)
                    .WithOne(c => c.TestLink)
                    .HasForeignKey(c => c.TestId)
                    .OnDelete(DeleteBehavior.SetNull);
            }
        }
        public class LicenseConfigurations : IEntityTypeConfiguration<License>
        {
            public void Configure(EntityTypeBuilder<License> builder)
            {
                builder.ToTable(nameof(License));
                builder.HasKey(c => c.LicenseId);
                builder.Property(c => c.LicenseDescription);
                builder
                    .HasMany(c => c.CrewLicenseList)
                    .WithOne(c => c.LicenseLink)
                    .HasForeignKey(c => c.LicenseId)
                    .OnDelete(DeleteBehavior.SetNull);
            }
        }
        public class TrainingConfigurations : IEntityTypeConfiguration<Training>
        {
            public void Configure(EntityTypeBuilder<Training> builder)
            {
                builder.ToTable(nameof(Training));
                builder.HasKey(c => c.TrainingId);
                builder.Property(c => c.TrainingDescription);
                builder.Property(c => c.TrainingFrequency);
                builder
                    .HasMany(c => c.CrewTrainingList)
                    .WithOne(c => c.TrainingLink)
                    .HasForeignKey(c => c.TrainingId)
                    .OnDelete(DeleteBehavior.SetNull);
            }
        }
        public class CrewLicenseConfigurations : IEntityTypeConfiguration<CrewLicense>
        {
            public void Configure(EntityTypeBuilder<CrewLicense> builder)
            {
                builder.ToTable(nameof(CrewLicense));
                builder.HasKey(c => c.CrewLicenseId);
                builder.Property(c => c.DateEarned);
                builder.Property(c => c.ExpirationDate);

            }
        }
        public class CrewTrainingConfigurations : IEntityTypeConfiguration<CrewTraining>
        {
            public void Configure(EntityTypeBuilder<CrewTraining> builder)
            {
                builder.ToTable(nameof(CrewTraining));
                builder.HasKey(c => c.CrewTrainingId);
                builder.Property(c => c.TrainingDescription);

            }
        }
        public class CrewTestConfigurations : IEntityTypeConfiguration<CrewTest>
        {
            public void Configure(EntityTypeBuilder<CrewTest> builder)
            {
                builder.ToTable(nameof(CrewTest));
                builder.HasKey(c => c.CrewTestId);
                builder.Property(c => c.TestDate);
                builder.Property(c => c.IsPassed);

            }
        }
        public class CrewAssignmentConfigurations : IEntityTypeConfiguration<CrewAssignment>
        {
            public void Configure(EntityTypeBuilder<CrewAssignment> builder)
            {
                builder.ToTable(nameof(CrewAssignment));
                builder.HasKey(c => c.FlightCrewId);
                builder
                    .HasOne(c => c.FlightLink)
                    .WithMany(c => c.FlightCrewList)
                    .HasForeignKey(c => c.CharterFlightId)
                    .OnDelete(DeleteBehavior.SetNull);
                builder
                    .HasOne(c => c.AircraftLink)
                    .WithMany(c => c.FlightCrewList)
                    .HasForeignKey(c => c.AircraftId)
                    .OnDelete(DeleteBehavior.SetNull);
                builder
                    .HasOne(c => c.CrewLink)
                    .WithMany(c => c.AssignmentList)
                    .HasForeignKey(c => c.CrewId)
                    .OnDelete(DeleteBehavior.SetNull);
            }
        }
        public class BillingConfigurations : IEntityTypeConfiguration<Billing>
        {
            public void Configure(EntityTypeBuilder<Billing> builder)
            {
                builder.ToTable(nameof(Billing));
                builder.HasKey(c => c.BillingId);
                builder.Property(c => c.WaitingExpense);
                builder.Property(c => c.DistanceExpense);
                builder.Property(c => c.CrewExpense);
                builder.Property(c => c.FuelExpense);
                builder
                    .HasMany(c => c.FlightList)
                    .WithOne(c => c.BillingLink)
                    .HasForeignKey(c => c.BillingId)
                    .OnDelete(DeleteBehavior.SetNull);
            }
        }
        public class ReservationConfigurations : IEntityTypeConfiguration<Reservation>
        {
            public void Configure(EntityTypeBuilder<Reservation> builder)
            {
                builder.ToTable(nameof(Reservation));
                builder.HasKey(c => c.ReservationId);
                builder.Property(c => c.ReservationDate);
                builder.Property(c => c.Destination);
                builder.Property(c => c.IsPassengerFlight);
                builder.Property(c => c.CargoWeight);
                builder.Property(c => c.NumberOfPassengers);
                builder
                    .HasOne(c => c.FlightLink)
                    .WithMany(c => c.ReservationList)
                    .HasForeignKey(c => c.FlightId)
                    .OnDelete(DeleteBehavior.SetNull);

            }
        }
        public class CharterFlightConfigurations : IEntityTypeConfiguration<CharterFlight>
        {
            public void Configure(EntityTypeBuilder<CharterFlight> builder)
            {
                builder.ToTable(nameof(CharterFlight));
                builder.HasKey(c => c.CharterFlightId);
                builder.Property(c => c.FlightDate);
                builder.Property(c => c.DepTime);
                builder.Property(c => c.ArrTime);
                builder.Property(c => c.Distance);
                builder
                    .HasOne(c => c.ReportLink)
                    .WithMany(c => c.FlightList)
                    .HasForeignKey(c => c.MonthlyReportId)
                    .OnDelete(DeleteBehavior.SetNull);

            }
        }
        public class MonthlyReportConfigurations : IEntityTypeConfiguration<MonthlyReport>
        {
            public void Configure(EntityTypeBuilder<MonthlyReport> builder)
            {
                builder.ToTable(nameof(MonthlyReport));
                builder.HasKey(c => c.MonthlyReportId);
                builder.Property(c => c.Revenues);
                builder.Property(c => c.OperatingCosts);
            }
        }
    }
}
