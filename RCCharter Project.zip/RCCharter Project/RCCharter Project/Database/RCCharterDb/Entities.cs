﻿using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace RCCharterDb
{
    public class Entities
    {

    }
    public class Customer
    {
        public int CustomerId { get; set; }
        public string CustomerName { get; set; }
        public bool HasCreditAuthorization { get; set; }
        public Account? AccountLink { get; set; }


        public List<Reservation> Reservations { get; set; }

        public List<Billing> Billings { get; set; }
        public Customer()
        {

        }
        public Customer(int customerId, string customerName, bool hasCreditAuthorization, Account accountLink)
        {
            CustomerId = customerId;
            CustomerName = customerName;
            HasCreditAuthorization = hasCreditAuthorization;
            AccountLink = accountLink;
        }
        public Customer(string customerName, bool hasCreditAuthorization, Account accountLink)
        {
            CustomerName = customerName;
            HasCreditAuthorization = hasCreditAuthorization;
            AccountLink = accountLink;
        }
        public Customer(int customerId, string customerName, bool hasCreditAuthorization)
        {
            CustomerId = customerId;
            CustomerName = customerName;
            HasCreditAuthorization = hasCreditAuthorization;
        }
        public Customer(string customerName, bool hasCreditAuthorization)
        {
            CustomerName = customerName;
            HasCreditAuthorization = hasCreditAuthorization;
        }
    }
    public class Aircraft
    {
        public int AircraftId { get; set; }
        public string Model { get; set; }
        public double TakeoffWeight { get; set; }
        public double WaitingCharge { get; set; }

        public List<Reservation> ReservationList { get; set; }

        public List<CrewAssignment> FlightCrewList { get; set; }
        public Aircraft()
        {

        }
        public Aircraft(string model, double takeoffWeight, double waitingCharge)
        {
            Model = model;
            TakeoffWeight = takeoffWeight;
            WaitingCharge = waitingCharge;
        }
    }
    public class Account
    {
        public int AccountId { get; set; }
        public double AccountBalance { get; set; }
        public double PartialPayable { get; set; }
        public int CustomerId { get; set; }
        public Customer CustomerLink { get; set; }

        public List<Billing> Billings { get; set; }
    }
    public class Test
    {
        public int TestId { get; set; }
        public string TestDescription { get; set; }
        public int TestFrequency { get; set; }

        public List<CrewTest> CrewTestList { get; set; }
    }
    public class License
    {
        public int LicenseId { get; set; }
        public string LicenseDescription { get; set; }

        public List<CrewLicense> CrewLicenseList { get; set; }
    }
    public class Training
    {
        public int TrainingId { get; set; }
        public string TrainingDescription { get; set; }
        public int TrainingFrequency { get; set; }

        public List<CrewTraining> CrewTrainingList { get; set; }
    }
    public class Crew
    {
        public int CrewId { get; set; }
        public string CrewName { get; set; }
        public List<CrewAssignment> AssignmentList { get; set; }
        public List<CrewLicense> CrewLicenseList { get; set; }
        public List<CrewTest> CrewTestList { get; set; }
        public List<CrewTraining> CrewTrainingList { get; set; }
        public Crew()
        {

        }
        public Crew(string name)
        {
            CrewName = name;
        }
    }
    public class CrewLicense
    {
        public int CrewLicenseId { get; set; }
        public DateTime DateEarned { get; set; }
        public DateTime ExpirationDate { get; set; }

        //Relationships
        public Crew? CrewLink { get; set; }
        public int? CrewId { get; set; }
        public License? LicenseLink { get; set; }
        public int? LicenseId { get; set; }
    }
    public class CrewTest
    {
        public int CrewTestId { get; set; }
        public DateTime TestDate { get; set; }
        public bool IsPassed { get; set; }

        //Relationships
        public Crew? CrewLink { get; set; }
        public int? CrewId { get; set; }
        public Test? TestLink { get; set; }
        public int? TestId { get; set; }
    }
    public class CrewTraining
    {
        public int CrewTrainingId { get; set; }
        public string TrainingDescription { get; set; }

        //Relationships
        public Crew? CrewLink { get; set; }
        public int? CrewId { get; set; }
        public Training? TrainingLink { get; set; }
        public int? TrainingId { get; set; }
    }
    public class CrewAssignment
    {
        public int FlightCrewId { get; set; }

        //Relationships
        public Aircraft? AircraftLink { get; set; }
        public int? AircraftId { get; set; }
        public Crew? CrewLink { get; set; }
        public int? CrewId { get; set; }
        public CharterFlight? FlightLink { get; set; }
        public int? CharterFlightId { get; set; }

    }
    public class CharterFlight:INotifyPropertyChanged
    {
        private int _flightId;
        public int CharterFlightId 
        {
            get { return _flightId; }
            set
            {
                _flightId = value;
                OnPropertyChanged();
            }
        }
        private DateTime _date;
        public DateTime FlightDate 
        {
            get { return _date; }
            set
            {
                _date = value;
                OnPropertyChanged();
            }
        }
        private TimeOnly _dep;
        public TimeOnly DepTime 
        {
            get { return _dep; }
            set
            {
                _dep = value;
                OnPropertyChanged();
            }
        }
        private TimeOnly _arr;
        public TimeOnly ArrTime 
        {
            get { return _arr; }
            set
            {
                _arr = value;
                OnPropertyChanged();
            }
        }
        private double _distance;
        public double Distance 
        {
            get { return _distance; }
            set
            {
                _distance = value;
                OnPropertyChanged();
            }
        }
        private double _fuel;
        public double FuelUsage 
        {
            get { return _fuel; }
            set
            {
                _fuel = value;
                OnPropertyChanged();
            }
        }

        //Relationships
        public List<CrewAssignment> FlightCrewList { get; set; }
        public List<Reservation> ReservationList { get; set; }
        public Billing? BillingLink { get; set; }
        public int? BillingId { get; set; }
        public MonthlyReport? ReportLink { get; set; }
        public int? MonthlyReportId { get; set; }
        public CharterFlight()
        {

        }
        public CharterFlight(int charterFlightID, DateTime flightDate, TimeOnly depTime, TimeOnly arrTime, double distance, double fuelUsage)
        {
            CharterFlightId = charterFlightID;
            FlightDate = flightDate;
            DepTime = depTime;
            ArrTime = arrTime;
            Distance = distance;
            FuelUsage = fuelUsage;
        }
        public CharterFlight(int charterFlightID, DateTime flightDate, TimeOnly depTime, TimeOnly arrTime, double distance)
        {
            CharterFlightId = charterFlightID;
            FlightDate = flightDate;
            DepTime = depTime;
            ArrTime = arrTime;
            Distance = distance;

        }
        public CharterFlight(DateTime flightDate, TimeOnly depTime, TimeOnly arrTime, double distance)
        {
            FlightDate = flightDate;
            DepTime = depTime;
            ArrTime = arrTime;
            Distance = distance;
        }

        public event PropertyChangedEventHandler? PropertyChanged;
        public void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {


            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));

        }
    }
    public class MonthlyReport
    {
        public int MonthlyReportId { get; set; }
        public double Revenues { get; set; }
        public double OperatingCosts { get; set; }

        public List<CharterFlight> FlightList { get; set; }

    }
    public class Billing : INotifyPropertyChanged
    {
        public int BillingId { get; set; }
        private double _waitingExpense;
        private double _distanceExpense;
        private double _crewExpense;
        private double _fuelExpense;
        public double WaitingExpense
        {
            get { return _waitingExpense; }
            set
            {
                _waitingExpense = value;
                OnPropertyChanged(nameof(TotalExpense));
            }
        }
        public double DistanceExpense
        {
            get { return _distanceExpense; }
            set
            {
                _distanceExpense = value;
                OnPropertyChanged(nameof(TotalExpense));
            }
        }
        public double CrewExpense
        {
            get { return _crewExpense; }
            set
            {
                _crewExpense = value;
                OnPropertyChanged(nameof(TotalExpense));
            }
        }
        public double FuelExpense
        {
            get { return _fuelExpense; }
            set
            {
                _fuelExpense = value;
                OnPropertyChanged(nameof(TotalExpense));
            }
        }
        private double _totalExpense;

        public event PropertyChangedEventHandler? PropertyChanged;

        public double TotalExpense
        {
            get
            {

                _totalExpense = WaitingExpense + DistanceExpense + CrewExpense + FuelExpense;
                return _totalExpense;
            }

        }
        //Relationships
        public Customer? CustomerLink { get; set; }
        public int? CustomerId { get; set; }
        public List<CharterFlight> FlightList { get; set; }
        public Account AccountLink { get; set; }
        public int AccountId { get; set; }
        public void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {


            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));

        }
    }

    public class Reservation
    {
        public int ReservationId { get; set; }
        public DateTime ReservationDate { get; set; }
        public string Destination { get; set; }
        public double? CargoWeight { get; set; }
        public int? NumberOfPassengers { get; set; }
        public bool IsPassengerFlight { get; set; }

        //Relationships
        public Customer? CustomerLink { get; set; }
        public int? CustomerId { get; set; }
        public Aircraft? AircraftLink { get; set; }
        public int? AircraftId { get; set; }
        public CharterFlight? FlightLink { get; set; }
        public int? FlightId { get; set; }
    }
}
