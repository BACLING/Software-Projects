﻿using Microsoft.EntityFrameworkCore;
using static RCCharterDb.Configuration;

namespace RCCharterDb
{

    public class CharterContext:DbContext
    {
        public DbSet<Customer> Customer { get; set; }
        public DbSet<Account> Account { get; set; }
        public DbSet<CharterFlight> CharterFlight { get; set; }
        public DbSet<Reservation> Reservation { get; set; }
        public DbSet<Billing> Billing { get; set; }
        public DbSet<CrewAssignment> CrewAssignment { get; set; }
        public DbSet<Crew> Crew { get; set; }
        public DbSet<CrewTest> CrewTest { get; set; }
        public DbSet<CrewTraining> CrewTraining { get; set; }
        public DbSet<CrewLicense> CrewLicense { get; set; }
        public DbSet<License> License { get; set; }
        public DbSet<Test> Test { get; set; }
        public DbSet<Training> Training { get; set; }
        public DbSet<MonthlyReport> MonthlyReport { get; set; }
        public DbSet<Aircraft> Aircraft { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlite(@"Data source = C:\Users\Matty\Desktop\RCFlightCompany.db");
            optionsBuilder.EnableSensitiveDataLogging();
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfiguration(new CustomerConfigurations());
            modelBuilder.ApplyConfiguration(new BillingConfigurations());
            modelBuilder.ApplyConfiguration(new ReservationConfigurations());
            modelBuilder.ApplyConfiguration(new CharterFlightConfigurations());
            modelBuilder.ApplyConfiguration(new CrewConfigurations());
            modelBuilder.ApplyConfiguration(new AircraftConfigurations());
            modelBuilder.ApplyConfiguration(new TestConfigurations());
            modelBuilder.ApplyConfiguration(new TrainingConfigurations());
            modelBuilder.ApplyConfiguration(new LicenseConfigurations());
            modelBuilder.ApplyConfiguration(new CrewTestConfigurations());
            modelBuilder.ApplyConfiguration(new CrewTrainingConfigurations());
            modelBuilder.ApplyConfiguration(new CrewLicenseConfigurations());
            modelBuilder.ApplyConfiguration(new CrewAssignmentConfigurations());
            modelBuilder.ApplyConfiguration(new AccountConfigurations());
        }
    }
}
