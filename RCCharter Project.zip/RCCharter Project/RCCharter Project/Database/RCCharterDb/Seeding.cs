﻿using Bogus;
using NUnit.Framework;
using NUnit.Framework.Internal;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace RCCharterDb
{
    public class Seeding
    {
        [OneTimeSetUp]
        public void ResetDatabase()
        {
            using var context = new CharterContext();
            context.Database.EnsureDeleted();
            context.Database.EnsureCreated();
        }
        [Test]
        public void SeedCustomerAndAccount()
        {
            using var context = new CharterContext();

            if (context.Customer.Any()) return;

            var faker = new Faker();
            bool[] bools = { true, false };

            
            var customers = new Faker<Customer>()
                .RuleFor(c => c.CustomerName, f => f.Name.FullName())
                .RuleFor(c => c.HasCreditAuthorization, f => f.PickRandom(bools))
                .Generate(100);

            var accounts = new List<Account>();

            foreach (var c in customers)
            {
                if (c.HasCreditAuthorization)
                {
                    var acc = new Account
                    {
                        AccountBalance = faker.Random.Double(0, 10000),
                        PartialPayable = faker.Random.Double(0, 10000),
                        CustomerLink = c
                    };

                    c.AccountLink = acc;
                    accounts.Add(acc);
                }
            }

            context.AddRange(customers);
            context.AddRange(accounts);
            context.SaveChanges(); 

            string[] aircraftModels = { "Boeing 737", "Airbus A320", "Boeing 757" };

            var aircraft = new Faker<Aircraft>()
                .RuleFor(a => a.Model, f => f.PickRandom(aircraftModels))
                .RuleFor(a => a.TakeoffWeight, f => f.Random.Double(50000, 250000))
                .RuleFor(a => a.WaitingCharge, f => f.Random.Double(5, 30))
                .Generate(30);

            context.AddRange(aircraft);
            context.SaveChanges();

            var customersWithAccounts = customers
                .Where(c => c.AccountLink != null)
                .ToList();

            var billings = new Faker<Billing>()
                .RuleFor(b => b.CustomerLink, f => f.PickRandom(customersWithAccounts))
                .RuleFor(b => b.AccountLink, (f, b) => b.CustomerLink.AccountLink)
                .RuleFor(b => b.WaitingExpense, f => f.Random.Double(0, 1000))
                .RuleFor(b => b.DistanceExpense, f => f.Random.Double(0, 1000))
                .RuleFor(b => b.CrewExpense, f => f.Random.Double(0, 1000))
                .RuleFor(b => b.FuelExpense, f => f.Random.Double(0, 1000))
                .Generate(50);

            context.AddRange(billings);
            context.SaveChanges();

            var reports = new Faker<MonthlyReport>()
                .RuleFor(r => r.Revenues, f => f.Random.Double(0, 1_000_000))
                .RuleFor(r => r.OperatingCosts, f => f.Random.Double(0, 1_000_000))
                .Generate(10);

            context.AddRange(reports);
            context.SaveChanges();

            var flights = new Faker<CharterFlight>()
                .RuleFor(f => f.BillingLink, f => f.PickRandom(billings))
                .RuleFor(f => f.ReportLink, f => f.PickRandom(reports))
                .RuleFor(f => f.FlightDate, f => f.Date.Recent(365))
                .RuleFor(f => f.DepTime, f => f.Date.BetweenTimeOnly(new TimeOnly(0, 0), new TimeOnly(23, 59)))
                .RuleFor(f => f.ArrTime, f => f.Date.BetweenTimeOnly(new TimeOnly(0, 0), new TimeOnly(23, 59)))
                .RuleFor(f => f.Distance, f => f.Random.Double(0, 1000))
                .RuleFor(f => f.FuelUsage, f => f.Random.Double(0, 1000))
                .Generate(50);

            context.AddRange(flights);
            context.SaveChanges();

            string[] cities = { "New York", "Chicago", "Dallas", "Seattle" };

            var reservations = new Faker<Reservation>()
                .RuleFor(r => r.FlightId, f => f.PickRandom(flights).CharterFlightId)
                .RuleFor(r => r.ReservationDate, f => f.Date.Recent(365))
                .RuleFor(r => r.Destination, f => f.PickRandom(cities))
                .RuleFor(r => r.IsPassengerFlight, f => f.PickRandom(bools))
                .RuleFor(r => r.CargoWeight, (f, r) => r.IsPassengerFlight ? null : f.Random.Double(1, 50000))
                .RuleFor(r => r.NumberOfPassengers, (f, r) => r.IsPassengerFlight ? f.Random.Int(1, 300) : null)
                .RuleFor(r => r.CustomerId, f => f.PickRandom(customers).CustomerId)
                .RuleFor(r => r.AircraftId, f => f.PickRandom(aircraft).AircraftId)
                .Generate(100);

            context.AddRange(reservations);
            context.SaveChanges();
            var crew = new Faker<Crew>()
                .RuleFor(c => c.CrewName, f => f.Name.FullName())
                .Generate(100);
            context.AddRange(crew);

            var assignmentGen = new Faker<CrewAssignment>()
                .RuleFor(c => c.AircraftLink, d => d.PickRandom(aircraft))
                .RuleFor(c => c.FlightLink, d => d.PickRandom(flights))
                .RuleFor(c => c.CrewLink, d => d.PickRandom(crew)); 
            
            var crewassignment = assignmentGen.Generate(100);
            context.AddRange(crewassignment);

            var licenseGen = new Faker<License>()
                .RuleFor(c => c.LicenseDescription, d => d.Random.Words()); 

            var license = licenseGen.Generate(100);
            context.AddRange(license);

            int[] frequency = { 1, 2, 4, 6, 12 }; 

            var testGen = new Faker<Test>()
                .RuleFor(c => c.TestDescription, d => d.Random.Words())
                .RuleFor(c => c.TestFrequency, d => d.PickRandom(frequency)); 

            var test = testGen.Generate(100);
            context.AddRange(test);

            var trainingGen = new Faker<Training>()
                .RuleFor(c => c.TrainingDescription, d => d.Random.Words())
                .RuleFor(c => c.TrainingFrequency, d => d.PickRandom(frequency)); 

            var training = trainingGen.Generate(100);
            context.AddRange(training);

            var crewLicenseGen = new Faker<CrewLicense>()
                .RuleFor(c => c.CrewLink, d => d.PickRandom(crew))
                .RuleFor(c => c.LicenseLink, d => d.PickRandom(license))
                .RuleFor(c => c.DateEarned, d => d.Date.Between(DateTime.Now.AddYears(-1), DateTime.Now))
                .RuleFor(c => c.ExpirationDate, (d, c) => c.DateEarned.AddYears(5)); 
            
            var crewLicense = crewLicenseGen.Generate(100);
            context.AddRange(crewLicense);

            bool[] values = { true, false };
            var crewtestGen = new Faker<CrewTest>()
                .RuleFor(c => c.CrewLink, d => d.PickRandom(crew))
                .RuleFor(c => c.TestLink, d => d.PickRandom(test))
                .RuleFor(c => c.TestDate, d => d.Date.Between(DateTime.Now.AddYears(-5), DateTime.Now))
                .RuleFor(c => c.IsPassed, d => d.PickRandom(values)); 
            
            var crewtest = crewtestGen.Generate(100);
            context.AddRange(crewtest);

            var crewtrainingGen = new Faker<CrewTraining>()
                .RuleFor(c => c.CrewLink, d => d.PickRandom(crew))
                .RuleFor(c => c.TrainingLink, d => d.PickRandom(training))
                .RuleFor(c => c.TrainingDescription, d => d.Random.Words()); 
            
            var crewtraining = crewtrainingGen.Generate(100); 
            context.AddRange(crewtraining);

            context.SaveChanges();
        }
        [OneTimeSetUp]
        public void DeleteDataBeforeAdd()
        {
            using var context = new CharterContext();
            context.Database.EnsureCreated();

            context.Set<Customer>().RemoveRange(context.Customer);
            context.Set<Account>().RemoveRange(context.Account);
            context.Set<Reservation>().RemoveRange(context.Reservation);
            context.Set<Aircraft>().RemoveRange(context.Aircraft);
            context.Set<Billing>().RemoveRange(context.Billing);
            context.Set<CharterFlight>().RemoveRange(context.CharterFlight);
            context.Set<MonthlyReport>().RemoveRange(context.MonthlyReport);
            context.Set<CrewAssignment>().RemoveRange(context.CrewAssignment);
            context.Set<Crew>().RemoveRange(context.Crew);
            context.Set<Training>().RemoveRange(context.Training);
            context.Set<Test>().RemoveRange(context.Test);
            context.Set<License>().RemoveRange(context.License);
            context.Set<CrewTest>().RemoveRange(context.CrewTest);
            context.Set<CrewTraining>().RemoveRange(context.CrewTraining);
            context.Set<CrewLicense>().RemoveRange(context.CrewLicense);

            context.SaveChanges();
        }
    }
}
