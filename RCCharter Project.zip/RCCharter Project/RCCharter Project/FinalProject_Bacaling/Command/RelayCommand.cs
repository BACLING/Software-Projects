﻿using System.Windows.Input;

namespace FinalProject_Bacaling.Command
{
    public class RelayCommand : ICommand
    {
        private ICommand? execute;
        private Func<object, bool> canExecute;

        public event EventHandler? CanExecuteChanged; //is called when conditions for whether
        // use action because the method should return void, and take in object
        private Action<object> _execute { get; set; }
        // use predicate because the method should return a boolean, and take in an object
        private Predicate<object> _canExecute { get; set; }
        public RelayCommand(Action<object> execute, Predicate<object> canExecute)
        {
            this._execute = execute;
            this._canExecute = canExecute;
        }

        public RelayCommand(ICommand? execute, Func<object, bool> canExecute)
        {
            this.execute = execute;
            this.canExecute = canExecute;
        }

        //parameter comes from the command
        // in our UI, when we invoke a command, we can pass an object
        public bool CanExecute(object? parameter)
        {
            return _canExecute(parameter);
        }
        public void Execute(object? parameter)
        {
            _execute(parameter);
        }
    }
}
