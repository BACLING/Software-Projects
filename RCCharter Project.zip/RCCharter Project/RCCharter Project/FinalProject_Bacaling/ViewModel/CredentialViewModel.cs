﻿using FinalProject_Bacaling.Command;
using RCCharterDb;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Input;

namespace FinalProject_Bacaling.ViewModel
{
    public class CredentialViewModel:NotifyPropertyChanged
    {
        private bool _isLicenseChecked;
        public bool IsLicenseChecked
        {
            get => _isLicenseChecked;
            set
            {
                if (_isLicenseChecked == value) return;

                _isLicenseChecked = value;

                if (value)
                {
                    _isTrainingChecked = false;
                    _isTestChecked = false;

                    OnPropertyChanged(nameof(IsTrainingChecked));
                    OnPropertyChanged(nameof(IsTestChecked));
                }

                OnPropertyChanged();
            }
        }

        private bool _isTrainingChecked;
        public bool IsTrainingChecked
        {
            get => _isTrainingChecked;
            set
            {
                if (_isTrainingChecked == value) return;

                _isTrainingChecked = value;

                if (value)
                {
                    _isLicenseChecked = false;
                    _isTestChecked = false;

                    OnPropertyChanged(nameof(IsLicenseChecked));
                    OnPropertyChanged(nameof(IsTestChecked));
                }

                OnPropertyChanged();
            }
        }

        private bool _isTestChecked;
        public bool IsTestChecked
        {
            get => _isTestChecked;
            set
            {
                if (_isTestChecked == value) return;

                _isTestChecked = value;

                if (value)
                {
                    _isLicenseChecked = false;
                    _isTrainingChecked = false;

                    OnPropertyChanged(nameof(IsLicenseChecked));
                    OnPropertyChanged(nameof(IsTrainingChecked));
                }

                OnPropertyChanged();
            }
        }
        private ObservableCollection<License> _licenses;
        public ObservableCollection<License> LicenseList 
        {
            get { return _licenses; }
            set
            {
                _licenses = value;
                OnPropertyChanged();
            }
        }
        private ObservableCollection<Training> _trainings;
        public ObservableCollection<Training> TrainingList 
        {
            get { return _trainings; }
            set
            {
                _trainings = value; 
                OnPropertyChanged();
            }
        }
        private ObservableCollection<Test> _tests;
        public ObservableCollection<Test> TestList 
        {
            get { return _tests; }
            set
            {
                _tests = value;
                OnPropertyChanged();
            }
        }
        private License _selectLicense;
        public License SelectedLicense 
        {
            get { return _selectLicense; }
            set
            {
                _selectLicense = value;
                OnPropertyChanged();
                EditLicense = new License
                {
                    LicenseDescription = _selectLicense.LicenseDescription
                };
            }
        }
        private Training _selectTraining;
        public Training SelectedTraining 
        {
            get { return _selectTraining; }
            set
            {
                _selectTraining = value;
                OnPropertyChanged();
                EditTraining = new Training
                {
                    TrainingDescription = _selectTraining.TrainingDescription,
                    TrainingFrequency = _selectTraining.TrainingFrequency
                };
            }
        }
        private Test _selectTest;
        public Test SelectedTest 
        {
            get { return _selectTest; }
            set
            {
                _selectTest = value;
                OnPropertyChanged();
                EditTest = new Test
                {
                    TestDescription = _selectTest.TestDescription,
                    TestFrequency = _selectTest.TestFrequency
                };
            }
        }
        private License _editLicense;
        public License EditLicense 
        {
            get { return _editLicense; }
            set
            {
                _editLicense = value;
                OnPropertyChanged();
            }
        }
        private Training _editTraining;
        public Training EditTraining 
        {
            get { return _editTraining; }
            set
            {
                _editTraining = value;
                OnPropertyChanged();
            }
        }
        private Test _editTest;
        public Test EditTest 
        {
            get { return _editTest; }
            set
            {
                _editTest = value;
                OnPropertyChanged();
            }
        }
        public ICommand DeleteCommand { get; set; }
        public ICommand AddCommand { get; set; }
        public string LicenseDescription { get; set; }
        public string TrainingDescription { get; set; }
        public int TrainingFrequency { get; set; } 
        public string TestDescription { get; set; }
        public int TestFrequency { get; set; }
        public ICommand SaveChangesCommand { get; set; }
        public CredentialViewModel()
        {
            LicenseList= new ObservableCollection<License>();
            TrainingList= new ObservableCollection<Training>(); 
            TestList= new ObservableCollection<Test>();
            DeleteCommand = new RelayCommand(Delete, CanDelete);
            AddCommand = new RelayCommand(Add, CanAdd);
            SaveChangesCommand = new RelayCommand(SaveChanges, CanSaveChanges);
            LoadData();
        }

        private bool CanSaveChanges(object obj)
        {
            return true;
        }

        private void SaveChanges(object obj)
        {
            var confirm = MessageBox.Show(
                "Are you sure you want to proceed?",
                "Confirm Action",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question
            );
            if (confirm == MessageBoxResult.Yes)
            {
                
                if(SelectedLicense == null && SelectedTraining == null && SelectedTest == null)
                {
                    MessageBox.Show("Please select a credential to edit");
                    return;
                }
                else
                {
                    using var context = new CharterContext();


                    if (SelectedLicense != null)
                    {
                        var license = context.License
                        .FirstOrDefault(c => c.LicenseId == SelectedLicense.LicenseId);
                        if (license != null)
                        {
                            license.LicenseDescription = EditLicense.LicenseDescription;
                            SelectedLicense.LicenseDescription = EditLicense.LicenseDescription;
                        }
                    }
                    if(SelectedTraining != null)
                    {
                        var training = context.Training
                        .FirstOrDefault(c => c.TrainingId == SelectedTraining.TrainingId);
                        if (training != null)
                        {
                            training.TrainingDescription = EditTraining.TrainingDescription;
                            training.TrainingFrequency = EditTraining.TrainingFrequency;
                            SelectedTraining.TrainingDescription = EditTraining.TrainingDescription;
                            SelectedTraining.TrainingFrequency = EditTraining.TrainingFrequency;
                        }
                    }
                    if(SelectedTest != null)
                    {
                        var test = context.Test
                        .FirstOrDefault(c => c.TestId == SelectedTest.TestId);

                        if (test != null)
                        {
                            test.TestDescription = EditTest.TestDescription;
                            test.TestFrequency = EditTest.TestFrequency;
                            SelectedTest.TestDescription = EditTest.TestDescription;
                            SelectedTest.TestFrequency = EditTest.TestFrequency;
                        }
                    }
                    context.SaveChanges();
                }
            }
        }

        private bool CanAdd(object obj)
        {
            return true;
        }

        private void Add(object obj)
        {
            var confirm = MessageBox.Show(
                "Are you sure you want to proceed?",
                "Confirm Action",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question
            );
            if (confirm == MessageBoxResult.Yes)
            {
                using var context = new CharterContext();
                if(IsLicenseChecked)
                {
                    var license = new License
                    {
                        LicenseDescription = LicenseDescription
                    };
                    context.License.Add(license);
                    context.SaveChanges();
                }
                else if(IsTrainingChecked)
                {
                    var training = new Training
                    {
                        TrainingDescription = TrainingDescription,
                        TrainingFrequency = TrainingFrequency
                    };
                    context.Training.Add(training);
                    context.SaveChanges();
                }
                else if(IsTestChecked)
                {
                    var test = new Test
                    {
                        TestDescription = TestDescription,
                        TestFrequency = TestFrequency
                    };
                    context.Test.Add(test); 
                    context.SaveChanges();
                }
                else
                {
                    MessageBox.Show("Please select credential type");
                    return;
                }
            }
        }

        private void LoadData()
        {
            using var context = new CharterContext();

            var licenses = context.License.ToList();
            var trainings = context.Training.ToList();
            var tests = context.Test.ToList();

            foreach(var item in licenses)
            {
                LicenseList.Add(item);
            }
            foreach(var item in trainings)
            {
                TrainingList.Add(item);
            }
            foreach(var item in tests)
            {
                TestList.Add(item);
            }
        }
        private bool CanDelete(object obj)
        {
            return true;
        }

        private void Delete(object obj)
        {
            var confirm = MessageBox.Show(
                "Are you sure you want to proceed?",
                "Confirm Action",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question
            );
            if (confirm == MessageBoxResult.Yes)
            {
                using var context = new CharterContext();
                if(SelectedLicense == null && SelectedTraining == null && SelectedTest == null)
                {
                    MessageBox.Show("Please select a credential");
                    return;
                }
                if(SelectedLicense != null)
                {
                    var license = context.License.FirstOrDefault(c => c.LicenseId == SelectedLicense.LicenseId);

                    var crewLicense = context.CrewLicense
                        .Where(c => c.LicenseId == SelectedLicense.LicenseId)
                        .ToList();

                    if (license == null) return;

                    context.CrewLicense.RemoveRange(crewLicense);
                    context.License.Remove(license);
                    context.SaveChanges();
                    LicenseList.Remove(SelectedLicense);
                }
                if(SelectedTraining != null)
                {
                    var training = context.Training.FirstOrDefault(c => c.TrainingId == SelectedTraining.TrainingId);

                    var crewTraining = context.CrewTraining
                        .Where(c => c.TrainingId == SelectedTraining.TrainingId)
                        .ToList();

                    if (training == null) return;

                    context.CrewTraining.RemoveRange(crewTraining);
                    context.Training.Remove(training);
                    context.SaveChanges();
                    TrainingList.Remove(SelectedTraining);
                }
                if(SelectedTest != null)
                {
                    var test = context.Test.FirstOrDefault(c => c.TestId == SelectedTest.TestId);

                    var crewTest = context.CrewTest
                        .Where(c => c.TestId == SelectedTest.TestId)
                        .ToList();

                    if (test == null) return;

                    context.CrewTest.RemoveRange(crewTest);
                    context.Test.Remove(test);
                    context.SaveChanges();
                    TestList.Remove(SelectedTest);
                }
                
            }
        }
    }
}
