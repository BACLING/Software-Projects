﻿using FinalProject_Bacaling.Command;
using RCCharterDb;
using System.Collections.ObjectModel;
using System.Security.Cryptography.X509Certificates;
using System.Windows;
using System.Windows.Input;

namespace FinalProject_Bacaling.ViewModel
{
    public class AddCustomerViewModel:NotifyPropertyChanged
    {
        private Customer _customer;
        public Customer AddedCustomer 
        {
            get { return _customer; }
            set
            {
                _customer = value;
                OnPropertyChanged();
            } 
        }
        private string _name;
        public string Name
        {
            get { return _name; }
            set 
            { 
                _name = value;
                OnPropertyChanged();
            }
        }
        private bool _authorization;
        public bool Authorization
        {
            get { return _authorization; }
            set
            {
                _authorization = value;
                OnPropertyChanged();
            }
        }
        private Account _acc;
        public Account Acc 
        {
            get { return _acc; }
            set
            {
                _acc = value;
                OnPropertyChanged();
            }
        }
        public ICommand AddCommand { get; set; }
        public AddCustomerViewModel()
        {
            AddCommand = new RelayCommand(Add, CanAdd);
            AuthorizationList = new ObservableCollection<bool> { true, false };
        }

        public ObservableCollection<bool> AuthorizationList { get; set; }
        private bool CanAdd(object obj)
        {
            return true;
        }

        private void Add(object obj)
        {
            using var context = new CharterContext();
            var confirm = MessageBox.Show("Are you sure you want to proceed?",
                "Confirm Action",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question
                );
            if(confirm == MessageBoxResult.Yes)
            {
                var newCustomer = new Customer
                {
                    CustomerName = Name,
                    HasCreditAuthorization = Authorization
                };

                if (Authorization == true)
                {
                    var account = new Account
                    {
                        AccountBalance = 0,
                        PartialPayable = 0
                    };

                    newCustomer.AccountLink = account;
                    context.Account.Add(account);
                }

                context.Customer.Add(newCustomer);
                
                context.SaveChanges();
            }
        }
    }
}
