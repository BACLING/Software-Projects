﻿using FinalProject_Bacaling.Command;
using RCCharterDb;
using Microsoft.EntityFrameworkCore;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Input;


namespace FinalProject_Bacaling.ViewModel
{
    public class FlightBillingViewModel: NotifyPropertyChanged
    {
        private CharterFlight _editFlight;
        public CharterFlight EditFlight 
        {
            get { return _editFlight; }
            set
            {
                _editFlight = value;
                OnPropertyChanged();
            }
        }
        private CharterFlight _selectedFlight;
        public CharterFlight SelectedFlight 
        {
            get { return _selectedFlight; }
            set
            {
                _selectedFlight = value;
                OnPropertyChanged();

                if (_selectedFlight == null) return;
                EditFlight = new CharterFlight
                {
                    CharterFlightId = _selectedFlight.CharterFlightId,
                    FlightDate = _selectedFlight.FlightDate,
                    DepTime = _selectedFlight.DepTime,
                    ArrTime = _selectedFlight.ArrTime,
                    Distance = _selectedFlight.Distance,
                    FuelUsage = _selectedFlight.FuelUsage,
                    BillingLink = new Billing
                    {
                        WaitingExpense = _selectedFlight.BillingLink.WaitingExpense,
                        DistanceExpense = _selectedFlight.BillingLink.DistanceExpense,
                        CrewExpense = _selectedFlight.BillingLink.CrewExpense,
                        FuelExpense = _selectedFlight.BillingLink.FuelExpense
                    }
                };
            }
        }

        private ObservableCollection<CharterFlight> _flightList;
        public ObservableCollection<CharterFlight> FlightList
        {
            get { return _flightList; }
            set 
            { 
                _flightList = value;
                OnPropertyChanged();
            }
        }
        private MonthlyReport _report;
        public MonthlyReport SelectedReport
        {
            get { return _report; }
            set
            {
                _report = value;
                OnPropertyChanged();
            }
        }
        private Billing _billing;
        public Billing SelectedBilling
        {
            get { return _billing; }
            set
            {
                _billing = value;
                OnPropertyChanged();
            }
        }
        private CharterFlight _flight;
        public CharterFlight AddedFlight
        {
            get { return _flight; }
            set
            {
                _flight = value;
                OnPropertyChanged();
            }
        }
        private DateTime _date;
        public DateTime FlightDate
        {
            get { return _date; }
            set
            {
                _date = value;
                OnPropertyChanged();
            }
        }
        private string _depTime;
        public string DepTime
        {
            get { return _depTime; }
            set
            {
                _depTime = value;
                OnPropertyChanged();
            }
        }
        private string _arrTime;
        public string ArrTime
        {
            get { return _arrTime; }
            set
            {
                _arrTime = value;
                OnPropertyChanged();
            }
        }
        private double _distance;
        public double Distance
        {
            get { return _distance; }
            set
            {
                _distance = value;
                OnPropertyChanged();
            }
        }
        private double _fuel;
        public double FuelUsage
        {
            get { return _fuel; }
            set
            {
                _fuel = value;
                OnPropertyChanged();
            }
        }
        public ObservableCollection<Billing> BillingList { get; set; }
        public ObservableCollection<MonthlyReport> ReportList { get; set; }
        public ICommand AddFlightCommand { get; set; }
        public ICommand SaveCommand { get; set; }
        public ICommand CancelCommand { get; set; }
        public ICommand DeleteCommand { get; set; }
        private Aircraft _aircraft;
        public Aircraft SelectedAircraft 
        {
            get { return _aircraft; }
            set
            {
                _aircraft = value;
                OnPropertyChanged();
            }
        }
        private ObservableCollection<Aircraft> _aircraftList;
        public ObservableCollection<Aircraft> AircraftList 
        {
            get { return _aircraftList; }
            set
            {
                _aircraftList = value;
                OnPropertyChanged();
            }
        }
        private ObservableCollection<CrewAssignment> _crewAssignmentList;
        public ObservableCollection<CrewAssignment> CrewAssignmentList 
        {
            get { return _crewAssignmentList; }
            set
            {
                _crewAssignmentList = value;
                OnPropertyChanged();
            }
        }
        private CrewAssignment _crewAssignment;
        public CrewAssignment SelectedCrewAssignment 
        {
            get { return _crewAssignment; }
            set
            {
                _crewAssignment = value;
                OnPropertyChanged();
            }
        }
        private Crew _selectedCrew;
        public Crew SelectedCrew 
        {
            get { return _selectedCrew; }
            set
            {
                _selectedCrew = value;
                OnPropertyChanged();
            }
        }
        public ICommand DeleteCrewAssignment { get; set; }
        private ObservableCollection<Crew> _crewList;
        public ObservableCollection<Crew> CrewList 
        {
            get { return _crewList; }
            set
            {
                _crewList = value;
                OnPropertyChanged();
            }
        }
        public ICommand AssignCommand { get; set; }
        public FlightBillingViewModel()
        {
            FlightList = new ObservableCollection<CharterFlight>();
            SaveCommand = new RelayCommand(Save, CanSave);
            CancelCommand = new RelayCommand(Cancel, CanCancel);
            DeleteCommand = new RelayCommand(Delete, CanDelete);
            BillingList = new ObservableCollection<Billing>();
            ReportList = new ObservableCollection<MonthlyReport>();
            AircraftList = new ObservableCollection<Aircraft>();
            CrewAssignmentList = new ObservableCollection<CrewAssignment>();
            AddFlightCommand = new RelayCommand(AddFlight, CanAddFlight);
            DeleteCrewAssignment = new RelayCommand(DeleteCrew, CanDeleteCrew);
            CrewList = new ObservableCollection<Crew>();
            AssignCommand = new RelayCommand(Assign, CanAssign);
            LoadData();
            CharterFlights();
        }

        private bool CanAssign(object obj)
        {
            return true;
        }

        private void Assign(object obj)
        {
            var confirm = MessageBox.Show(
                "Are you sure you want to proceed?",
                "Confirm Action",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question
            );
            if(confirm == MessageBoxResult.Yes)
            {
                using var context = new CharterContext();

                var crewAssignment = new CrewAssignment
                {
                    CrewId = SelectedCrew.CrewId,
                    CharterFlightId = SelectedFlight.CharterFlightId,
                    AircraftId = SelectedAircraft.AircraftId
                };

                context.CrewAssignment.Add(crewAssignment);
                context.SaveChanges();
            }
        }

        private bool CanDeleteCrew(object obj)
        {
            return true;
        }

        private void DeleteCrew(object obj)
        {
            var confirm = MessageBox.Show(
                "Are you sure you want to proceed?",
                "Confirm Action",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question
            );
            if(confirm == MessageBoxResult.Yes)
            {
                using var context = new CharterContext();

                var crewAssignment = context.CrewAssignment
                    .FirstOrDefault(c => c.FlightCrewId == SelectedCrewAssignment.FlightCrewId);
                if (crewAssignment == null) return;

                context.CrewAssignment.Remove(crewAssignment);
                context.SaveChanges();
                CrewAssignmentList.Remove(SelectedCrewAssignment);
            }
        }

        private bool CanAddFlight(object obj)
        {
            return true;
        }

        private void AddFlight(object obj)
        {
            using var context = new CharterContext();

            var confirm = MessageBox.Show(
                "Are you sure you want to proceed?",
                "Confirm Action",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question
            );

            if (confirm != MessageBoxResult.Yes || SelectedReport == null) return;

            var flight = new CharterFlight
            {
                MonthlyReportId = SelectedReport.MonthlyReportId,
                FlightDate = FlightDate,
                DepTime = TimeOnly.Parse(DepTime),
                ArrTime = TimeOnly.Parse(ArrTime),
                Distance = Distance,
                FuelUsage = FuelUsage,
                BillingId = SelectedBilling.BillingId
            };
            context.CharterFlight.Add(flight);
            context.SaveChanges();
            FlightList.Add(flight);
        }
        private void LoadData()
        {
            using var context = new CharterContext();

            var crews = context.Crew
                .ToList();

            var aircraft = context.Aircraft
                .ToList();

            var crewAssignment = context.CrewAssignment
                .Include(c => c.CrewLink)
                .Include(c => c.AircraftLink)
                .Include(c => c.FlightLink)
                .ToList();

            var report = context.MonthlyReport
                .ToList();

            var billing = context.Billing
                .ToList();

            foreach(var crew in crews)
            {
                CrewList.Add(crew);
            }

            foreach (var item in report)
            {
                ReportList.Add(item);
            }
            foreach (var item in billing)
            {
                BillingList.Add(item);
            }
            foreach(var air in aircraft)
            {
                AircraftList.Add(air);
            }
            foreach(var crewAssign in crewAssignment)
            {
                CrewAssignmentList.Add(crewAssign);
            }
        }
        private bool CanDelete(object obj)
        {
            return true;
        }

        private void Delete(object obj)
        {
            
            var confirm = MessageBox.Show(
                "Are you sure you want to proceed?",
                "Confirm Action",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question
            );
            if (confirm == MessageBoxResult.Yes)
            {
                using var context = new CharterContext();

                var flight = context.CharterFlight
                    .FirstOrDefault(c => c.CharterFlightId == SelectedFlight.CharterFlightId);

                if (flight == null) return;

                var reservations = context.Reservation
                    .Where(c => c.FlightId == flight.CharterFlightId)
                    .ToList();
                
                var crewAssignment = context.CrewAssignment
                    .Where(c => c.CharterFlightId == flight.CharterFlightId)
                    .ToList();

                context.RemoveRange(reservations);
                context.RemoveRange(crewAssignment);
                context.CharterFlight.Remove(flight);
                context.SaveChanges();
                FlightList.Remove(SelectedFlight);
            }
            
        }

        private bool CanSave(object obj)
        {
            return true;
        }

        private void Save(object obj)
        {
            var confirm = MessageBox.Show(
                "Are you sure you want to proceed?",
                "Confirm Action",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question
            );
            if(confirm == MessageBoxResult.Yes )
            {
                using var context = new CharterContext();

                var flight = context.CharterFlight
                    .Include(c => c.BillingLink)
                    .FirstOrDefault(c => c.CharterFlightId == EditFlight.CharterFlightId);

                if (EditFlight == null) return;
                if (flight != null)
                {
                    flight.FlightDate = EditFlight.FlightDate;
                    flight.DepTime = EditFlight.DepTime;
                    flight.ArrTime = EditFlight.ArrTime;
                    flight.Distance = EditFlight.Distance;
                    flight.FuelUsage = EditFlight.FuelUsage;
                    flight.BillingLink.WaitingExpense = EditFlight.BillingLink.WaitingExpense;
                    flight.BillingLink.DistanceExpense = EditFlight.BillingLink.DistanceExpense;
                    flight.BillingLink.CrewExpense = EditFlight.BillingLink.CrewExpense;
                    flight.BillingLink.FuelExpense = EditFlight.BillingLink.FuelExpense;
                    context.SaveChanges();
                }
                SelectedFlight.FlightDate = EditFlight.FlightDate;
                SelectedFlight.DepTime = EditFlight.DepTime;
                SelectedFlight.ArrTime = EditFlight.ArrTime;
                SelectedFlight.Distance = EditFlight.Distance;
                SelectedFlight.FuelUsage = EditFlight.FuelUsage;
                SelectedFlight.BillingLink.WaitingExpense = EditFlight.BillingLink.WaitingExpense;
                SelectedFlight.BillingLink.DistanceExpense = EditFlight.BillingLink.DistanceExpense;
                SelectedFlight.BillingLink.CrewExpense = EditFlight.BillingLink.CrewExpense;
                SelectedFlight.BillingLink.FuelExpense = EditFlight.BillingLink.FuelExpense;
            }
        }
        private bool CanCancel(object obj)
        {
            return true;
        }

        private void Cancel(object obj)
        {
            var confirm = MessageBox.Show(
                "Are you sure you want to proceed?",
                "Confirm Action",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question
            );
            if(confirm == MessageBoxResult.Yes)
            {
                if (SelectedFlight == null) return;
                EditFlight = new CharterFlight
                {
                    CharterFlightId = SelectedFlight.CharterFlightId,
                    DepTime = SelectedFlight.DepTime,
                    ArrTime = SelectedFlight.ArrTime,
                    Distance = SelectedFlight.Distance,
                    FuelUsage = SelectedFlight.FuelUsage,
                    BillingLink = new Billing
                    {
                        WaitingExpense = SelectedFlight.BillingLink.WaitingExpense,
                        DistanceExpense = SelectedFlight.BillingLink.DistanceExpense,
                        CrewExpense = SelectedFlight.BillingLink.CrewExpense,
                        FuelExpense = SelectedFlight.BillingLink.FuelExpense
                    }
                };
            }
        }

        private void CharterFlights()
        {
            using var context = new CharterContext();

            var result = context.CharterFlight
                .Include(c => c.ReportLink)
                .Include(c => c.BillingLink)
                .ThenInclude(c => c.CustomerLink)
                .ToList();

            foreach (var flight in result)
            {
                FlightList.Add(flight);
            }
        }
    }
}
