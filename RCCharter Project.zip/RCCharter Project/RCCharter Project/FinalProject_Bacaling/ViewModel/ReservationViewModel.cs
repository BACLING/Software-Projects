﻿using FinalProject_Bacaling.Command;
using Microsoft.EntityFrameworkCore;
using RCCharterDb;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Input;

namespace FinalProject_Bacaling.ViewModel
{
    public class ReservationViewModel: NotifyPropertyChanged
    {
        private DateTime _reserve;
        public DateTime ReservationDate 
        {
            get { return _reserve; }
            set
            {
                _reserve = value;
                OnPropertyChanged();
            }
        }
        private string _destination;
        public string Destination 
        {
            get { return _destination; }
            set
            {
                _destination = value;
                OnPropertyChanged();
            }
        }
        private double? _weight;
        public double? CargoWeight 
        {
            get { return _weight; }
            set
            {
                _weight = value;
                OnPropertyChanged();
            }
        }
        private int? _passenger;
        public int? NumberOfPassengers 
        {
            get { return _passenger; }
            set
            {
                _passenger = value;
                OnPropertyChanged();
            }
        }
        private bool _isPassenger;
        public bool IsPassengerFlight
        {
            get => _isPassenger;
            set
            {
                if (_isPassenger == value) return;

                _isPassenger = value;

                OnPropertyChanged();                     
                OnPropertyChanged(nameof(IsCargoFlight)); 
            }
        }

        public bool IsCargoFlight
        {
            get => !_isPassenger;
            set
            {
                if (_isPassenger == !value) return;

                _isPassenger = !value;

                OnPropertyChanged(nameof(IsPassengerFlight));
                OnPropertyChanged(nameof(IsCargoFlight));
            }
        }
        public ICommand SaveCommand { get; set; }
        public ICommand CancelCommand { get; set; }
        public ICommand AddCommand { get; set; }
        public ICommand DeleteCommand { get; set; }
        public ICommand AddAircraftCommand { get; set; }
        private ObservableCollection<Customer> _customerList;
        public ObservableCollection<Customer> CustomerList 
        {
            get { return _customerList; }
            set
            {
                _customerList = value;
                OnPropertyChanged();
            }
        }
        private Customer _customer;
        public Customer SelectedCustomer 
        {
            get { return _customer; }
            set
            {
                _customer = value;
                OnPropertyChanged();
                
            }
        }
        private ObservableCollection<CharterFlight> _flightList;
        public ObservableCollection<CharterFlight> FlightList 
        {
            get { return _flightList; }
            set
            {
                _flightList = value;
                OnPropertyChanged();
            }
        }
        private CharterFlight _flight;
        public CharterFlight SelectedFlight 
        {
            get { return _flight; }
            set
            {
                _flight = value;
                OnPropertyChanged();
            }
        }
        private ObservableCollection<Aircraft> _aircraftList;
        public ObservableCollection<Aircraft> AircraftList
        {
            get { return _aircraftList; }
            set
            {
                _aircraftList = value;
                OnPropertyChanged();
            }
        }
        private Aircraft _aircraft;
        public Aircraft SelectedAircraft 
        {
            get { return _aircraft; }
            set
            {
                _aircraft = value;
                OnPropertyChanged();

                if(_aircraft != null)
                {
                    EditAircraft = new Aircraft
                    {
                        AircraftId = _aircraft.AircraftId,
                        Model = _aircraft.Model,
                        TakeoffWeight = _aircraft.TakeoffWeight,
                        WaitingCharge = _aircraft.WaitingCharge
                    };
                }
            }
        }
        private Aircraft _editAircraft;
        public Aircraft EditAircraft 
        {
            get { return _editAircraft; }
            set
            {
                _editAircraft = value;
                OnPropertyChanged();
            }
        }
        private ObservableCollection<Reservation> _reservationList;
        public ObservableCollection<Reservation> ReservationList 
        {
            get { return _reservationList; }
            set 
            {  
                _reservationList = value;
                OnPropertyChanged();
            } 
        }
       
        private Reservation _editableReservation;
        public Reservation EditableReservation
        {
            get => _editableReservation;
            set
            {
                _editableReservation = value;
                OnPropertyChanged();
            }
        }
        private Reservation _reservation;
        public Reservation SelectedReservation
        {
            get { return _reservation; }
            set
            {
                _reservation = value;
                OnPropertyChanged();

                if (_reservation != null)
                {
                    EditableReservation = new Reservation
                    {
                        ReservationId = _reservation.ReservationId,
                        Destination = _reservation.Destination,
                        ReservationDate = _reservation.ReservationDate,
                        CargoWeight = _reservation.CargoWeight,
                        NumberOfPassengers = _reservation.NumberOfPassengers,
                        CustomerId = _reservation.CustomerId,
                        AircraftId = _reservation.AircraftId
                    };
                }
            }
        }
        public ICommand DeleteAircraftCommand { get; set; }
        public ICommand CancelAircraftChanges { get; set; }
        public ICommand SaveAircraftChanges { get; set; }
        private string _model;
        public string Model 
        {
            get { return _model; }
            set
            {
                _model = value;
                OnPropertyChanged();
            }
        }
        private double _takeoffWeight;
        public double TakeOffWeight 
        {
            get { return _takeoffWeight; }
            set
            {
                _takeoffWeight = value;
                OnPropertyChanged();
            } 
        }
        private double _waitingCharge;
        public double WaitingCharge 
        {
            get { return _waitingCharge; }
            set
            {
                _waitingCharge = value;
                OnPropertyChanged();
            }
        }
        public ReservationViewModel()
        {
            AddCommand = new RelayCommand(Add, CanAdd);
            SaveCommand = new RelayCommand(Save, CanSave);
            CancelCommand = new RelayCommand(Cancel, CanCancel);
            DeleteCommand = new RelayCommand(Delete, CanDelete);
            ReservationList = new ObservableCollection<Reservation>();
            CustomerList = new ObservableCollection<Customer>();
            FlightList = new ObservableCollection<CharterFlight>();
            AircraftList = new ObservableCollection<Aircraft>();
            DeleteAircraftCommand = new RelayCommand(DeleteAircraft, CanDeleteAircraft);
            CancelAircraftChanges = new RelayCommand(CancelAircraft, CanCancelAircraft);
            SaveAircraftChanges = new RelayCommand(SaveAircraft, CanSaveAircraft);
            AddAircraftCommand = new RelayCommand(AddAircraft, CanAddAircraft);
            Reservations();
            LoadData();
        }

        private bool CanAddAircraft(object obj)
        {
            return true;
        }

        private void AddAircraft(object obj)
        {
            var confirm = MessageBox.Show(
               "Are you sure you want to proceed?",
               "Confirm Action",
               MessageBoxButton.YesNo,
               MessageBoxImage.Question
           );
            if(confirm == MessageBoxResult.Yes)
            {
                using var context = new CharterContext();

                var addedAircraft = new Aircraft
                {
                    Model = Model,
                    TakeoffWeight = TakeOffWeight,
                    WaitingCharge = WaitingCharge,
                };

                context.Aircraft.Add(addedAircraft);
                context.SaveChanges();
                AircraftList.Add(addedAircraft);
            }
        }

        private bool CanDeleteAircraft(object obj)
        {
            return true;
        }

        private void DeleteAircraft(object obj)
        {
            var confirm = MessageBox.Show(
                "Are you sure you want to proceed?",
                "Confirm Action",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question
            );
            if (confirm == MessageBoxResult.Yes)
            {
                using var context = new CharterContext();
                if (SelectedAircraft != null)
                {
                    var aircraft = context.Aircraft
                        .FirstOrDefault(c => c.AircraftId == SelectedAircraft.AircraftId);

                    var crewAssignment = context.CrewAssignment
                        .Where(c => c.AircraftId == aircraft.AircraftId)
                        .ToList();

                    var reservation = context.Reservation
                        .Where(c => c.AircraftId == aircraft.AircraftId)
                        .ToList();


                    if (aircraft == null) return;

                    context.RemoveRange(crewAssignment);
                    context.RemoveRange(reservation);
                    context.Aircraft.Remove(aircraft);
                    context.SaveChanges();
                    
                    foreach(var r in reservation)
                    {
                        ReservationList.Remove(r);
                    }
                    
                    AircraftList.Remove(SelectedAircraft);
                }
            }
        }

        private bool CanDelete(object obj)
        {
            return true;
        }

        private void Delete(object obj)
        {
            var confirm = MessageBox.Show(
                "Are you sure you want to proceed?",
                "Confirm Action",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question
            );
            if(confirm == MessageBoxResult.Yes )
            {
                using var context = new CharterContext();

                var reservation = context.Reservation
                    .FirstOrDefault(c => c.ReservationId == SelectedReservation.ReservationId);

                if(reservation != null)
                {
                    context.Reservation.Remove(reservation);
                    context.SaveChanges();
                    ReservationList.Remove(SelectedReservation);
                }
            }
        }

        private void LoadData()
        {
            using var context = new CharterContext();

            var aircrafts = context.Aircraft
                .ToList();

            var flights = context.CharterFlight
                .ToList();

            var customers = context.Customer
                .ToList();

            foreach (var flight in flights)
            {
                FlightList.Add(flight);
            }
            foreach (var customer in customers)
            {
                CustomerList.Add(customer);
            }
            foreach (var aircraft in aircrafts)
            {
                AircraftList.Add(aircraft);
            }
        }
        private bool CanAdd(object obj)
        {
            return true;
        }

        private void Add(object obj)
        {
            using var context = new CharterContext();
            var confirm = MessageBox.Show(
                "Are you sure you want to proceed?",
                "Confirm Action",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question
            );
            if(confirm == MessageBoxResult.Yes)
            {
                if (SelectedCustomer == null ||
                    SelectedAircraft == null ||
                    SelectedFlight == null)
                {
                    MessageBox.Show("Please complete all selections.");
                    return;
                }

                if (IsPassengerFlight == true)
                {
                    var reservation = new Reservation
                    {
                        ReservationDate = ReservationDate,
                        Destination = Destination,
                        NumberOfPassengers = NumberOfPassengers,
                        CargoWeight = null,
                        IsPassengerFlight = IsPassengerFlight,
                        CustomerId = SelectedCustomer.CustomerId,
                        AircraftId = SelectedAircraft.AircraftId,
                        FlightId = SelectedFlight.CharterFlightId
                    };
                    context.Reservation.Add(reservation);
                    ReservationList.Add(reservation);
                }
                else
                {
                    var reservation = new Reservation
                    {
                        ReservationDate = ReservationDate,
                        Destination = Destination,
                        NumberOfPassengers = null,
                        CargoWeight = CargoWeight,
                        IsPassengerFlight = IsPassengerFlight,
                        CustomerId = SelectedCustomer.CustomerId,
                        AircraftId = SelectedAircraft.AircraftId,
                        FlightId = SelectedFlight.CharterFlightId
                    };
                    context.Reservation.Add(reservation);
                    ReservationList.Add(reservation);
                }
                
                context.SaveChanges();
            }
        }

        private bool CanCancel(object obj)
        {
            return true;
        }
        private void Cancel(object obj)
        {
            var confirm = MessageBox.Show(
                "Are you sure you want to proceed?",
                "Confirm Action",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question
            );
            if(confirm == MessageBoxResult.Yes)
            {
                if (SelectedReservation == null) return;
                EditableReservation = new Reservation
                {
                    ReservationId = SelectedReservation.ReservationId,
                    Destination = SelectedReservation.Destination,
                    ReservationDate = SelectedReservation.ReservationDate,
                    CargoWeight = SelectedReservation.CargoWeight,
                    NumberOfPassengers = SelectedReservation.NumberOfPassengers,
                    CustomerId = SelectedReservation.CustomerId,
                    AircraftId = SelectedReservation.AircraftId
                };
            }
            
        }
        private bool CanSave(object obj)
        {
            return true;
        }

        private void Save(object obj)
        {
            using var context = new CharterContext();
            var reservation = context.Reservation
                    .FirstOrDefault(r => r.ReservationId == EditableReservation.ReservationId);

            var confirm = MessageBox.Show(
                "Are you sure you want to proceed?",
                "Confirm Action",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question
            );
            if(confirm == MessageBoxResult.Yes)
            {
                if (EditableReservation == null) return;
                if (reservation != null)
                {
                    reservation.Destination = EditableReservation.Destination;
                    reservation.ReservationDate = EditableReservation.ReservationDate;
                    reservation.CargoWeight = EditableReservation.CargoWeight;
                    reservation.NumberOfPassengers = EditableReservation.NumberOfPassengers;
                    context.SaveChanges();
                }
                SelectedReservation.Destination = EditableReservation.Destination;
                SelectedReservation.ReservationDate = EditableReservation.ReservationDate;
                SelectedReservation.CargoWeight = EditableReservation.CargoWeight;
                SelectedReservation.NumberOfPassengers = EditableReservation.NumberOfPassengers;
            }
        }
        private bool CanCancelAircraft(object obj)
        {
            return true;
        }

        private void CancelAircraft(object obj)
        {
            var confirm = MessageBox.Show(
                "Are you sure you want to proceed?",
                "Confirm Action",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question
            );
            if (confirm == MessageBoxResult.Yes)
            {
                if(SelectedAircraft == null) return;
                EditAircraft = new Aircraft
                {
                    AircraftId = SelectedAircraft.AircraftId,
                    Model = SelectedAircraft.Model,
                    TakeoffWeight = SelectedAircraft.TakeoffWeight,
                    WaitingCharge = SelectedAircraft.WaitingCharge
                };
            }
        }
        private bool CanSaveAircraft(object obj)
        {
            return true;
        }

        private void SaveAircraft(object obj)
        {
            var confirm = MessageBox.Show(
                "Are you sure you want to proceed?",
                "Confirm Action",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question
            );
            if(confirm == MessageBoxResult.Yes)
            {
                using var context = new CharterContext();

                var aircraft = context.Aircraft
                    .FirstOrDefault(c => c.AircraftId == EditAircraft.AircraftId);
                if (EditAircraft == null) return;
                if(aircraft != null)
                {
                    aircraft.Model = EditAircraft.Model;
                    aircraft.TakeoffWeight = EditAircraft.TakeoffWeight;
                    aircraft.WaitingCharge = EditAircraft.WaitingCharge;
                    context.SaveChanges();
                }
                SelectedAircraft.Model = EditAircraft.Model;
                SelectedAircraft.TakeoffWeight = EditAircraft.TakeoffWeight;
                SelectedAircraft.WaitingCharge = EditAircraft.WaitingCharge;
            }
        }
        private void Reservations()
        {
            using var context = new CharterContext();
            
            var result = context.Reservation
                .Include(c => c.AircraftLink)
                .Include(c => c.CustomerLink)
                .ToList();
            
            foreach (var item in  result)
            {
                ReservationList.Add(item);
            }
        }
    }
}
