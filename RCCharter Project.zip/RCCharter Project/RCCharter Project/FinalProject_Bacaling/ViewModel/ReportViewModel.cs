﻿using FinalProject_Bacaling.Command;
using Microsoft.EntityFrameworkCore;
using RCCharterDb;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media.Media3D;

namespace FinalProject_Bacaling.ViewModel
{
    public class ReportViewModel:NotifyPropertyChanged
    {
        private ObservableCollection<MonthlyReport> _report;
        public ObservableCollection<MonthlyReport> ReportList 
        {
            get { return _report; }
            set
            {
                _report = value;
                OnPropertyChanged();
            }
        }
        private MonthlyReport _selectReport;
        public MonthlyReport SelectedReport 
        {
            get { return _selectReport; }
            set
            {
                _selectReport = value;
                OnPropertyChanged();

                EditReport = new MonthlyReport
                {
                    Revenues = _selectReport.Revenues,
                    OperatingCosts = _selectReport.OperatingCosts
                };
            }
        }
        private MonthlyReport _editReport;
        public MonthlyReport EditReport 
        {
            get { return _editReport; }
            set
            {
                _editReport = value;
                OnPropertyChanged();
            }
        }
        private double _revenues;
        public double Revenues 
        {
            get { return _revenues; }
            set
            {
                _revenues = value;
                OnPropertyChanged();
            }
        }
        private double _costs;
        public double OperatingCosts 
        {
            get { return _costs; }
            set
            {
                _costs = value;
                OnPropertyChanged();
            }
        }
        public ICommand SaveCommand { get; set; }
        public ICommand AddReportCommand { get; set; }
        public ICommand DeleteReportCommand { get; set; }
        public ReportViewModel()
        {
            SaveCommand = new RelayCommand(Save, CanSave);
            AddReportCommand = new RelayCommand(AddReport, CanAddReport);
            DeleteReportCommand = new RelayCommand(Delete, CanDelete);
            ReportList = new ObservableCollection<MonthlyReport>();
            LoadData();
        }

        private bool CanDelete(object obj)
        {
            return true;
        }

        private void Delete(object obj)
        {
            var confirm = MessageBox.Show(
                "Are you sure you want to proceed?",
                "Confirm Action",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question
            );
            if (confirm == MessageBoxResult.Yes)
            {
                using var context = new CharterContext();
                if(SelectedReport != null)
                {
                    var report = context.MonthlyReport
                    .FirstOrDefault(c => c.MonthlyReportId == SelectedReport.MonthlyReportId);

                    var relatedFlights = context.CharterFlight
                        .Where(c => c.MonthlyReportId == SelectedReport.MonthlyReportId)
                        .ToList();

                    foreach(var flight in relatedFlights)
                    {
                        var reservations = context.Reservation
                            .Where(c => c.FlightId == flight.CharterFlightId)
                            .ToList();

                        var crewAssignment = context.CrewAssignment
                            .Where(c => c.CharterFlightId == flight.CharterFlightId)
                            .ToList();

                        context.Reservation.RemoveRange(reservations);
                        context.CrewAssignment.RemoveRange(crewAssignment);
                    }

                    if (report == null) return;

                    context.CharterFlight.RemoveRange(relatedFlights);
                    context.MonthlyReport.Remove(report);
                    context.SaveChanges();
                    ReportList.Remove(SelectedReport);
                }
            }
        }

        private bool CanAddReport(object obj)
        {
            return true;
        }

        private void AddReport(object obj)
        {
            var confirm = MessageBox.Show(
                "Are you sure you want to proceed?",
                "Confirm Action",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question
            );
            if (confirm == MessageBoxResult.Yes)
            {
                using var context = new CharterContext();

                var add = new MonthlyReport
                {
                    Revenues = Revenues,
                    OperatingCosts = OperatingCosts
                };
                context.MonthlyReport.Add(add);
                context.SaveChanges();
            }
        }

        private void LoadData()
        {
            using var context = new CharterContext();

            var reports = context.MonthlyReport
                .Include(c => c.FlightList)
                .ToList();
                        
            foreach(var item in reports)
            {
                ReportList.Add(item);
            }
        }

        private bool CanSave(object obj)
        {
            return true;
        }

        private void Save(object obj)
        {
            var confirm = MessageBox.Show(
                "Are you sure you want to proceed?",
                "Confirm Action",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question
            );
            if (confirm == MessageBoxResult.Yes)
            {
                using var context = new CharterContext();
                if(SelectedReport != null)
                {
                    var report = context.MonthlyReport
                    .FirstOrDefault(c => c.MonthlyReportId == SelectedReport.MonthlyReportId);
                    if (report == null) return;

                    report.Revenues = EditReport.Revenues;
                    report.OperatingCosts = EditReport.OperatingCosts;
                    context.SaveChanges();
                    SelectedReport.Revenues = EditReport.Revenues;
                    SelectedReport.OperatingCosts = EditReport.OperatingCosts;
                }
            }
        }
    }
}
