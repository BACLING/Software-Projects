﻿using FinalProject_Bacaling.Command;
using Microsoft.EntityFrameworkCore;
using RCCharterDb;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Input;

namespace FinalProject_Bacaling.ViewModel
{
    public class EmployeeViewModel: NotifyPropertyChanged
    {
        private ObservableCollection<Crew> _crewList;
        public ObservableCollection<Crew> CrewList 
        {
            get { return _crewList; }
            set 
            { 
                _crewList = value; 
                OnPropertyChanged();
            }
        }
        private ObservableCollection<License> _licenseList;
        public ObservableCollection<License> LicenseList 
        {
            get { return _licenseList; }
            set
            {
                _licenseList = value;
                OnPropertyChanged();
            }
        }
        private ObservableCollection<Training> _trainingList;
        public ObservableCollection<Training> TrainingList 
        {
            get { return _trainingList; }
            set 
            { 
                _trainingList = value; 
                OnPropertyChanged(); 
            }
        }
        private ObservableCollection<Test> _testList;
        public ObservableCollection<Test> TestList 
        {
            get { return _testList; }
            set 
            { 
                _testList = value;
                OnPropertyChanged();
            }
        }
        private ObservableCollection<License> _totalLicenseList;
        public ObservableCollection<License> TotalLicenseList 
        {
            get { return _totalLicenseList; }
            set
            {
                _totalLicenseList = value;
                OnPropertyChanged();
            }
        }
        private ObservableCollection<Training> _totalTrainingList;
        public ObservableCollection<Training> TotalTrainingList 
        {
            get { return _totalTrainingList; }
            set 
            {
                _totalTrainingList = value; 
                OnPropertyChanged(); 
            }
        }
        private ObservableCollection<Test> _totalTestList;
        public ObservableCollection<Test> TotalTestList 
        {
            get { return _totalTestList; }
            set 
            {
                _totalTestList = value;
                OnPropertyChanged();
            }
        }
        private Crew _selectedCrew;
        public Crew SelectedCrew 
        {
            get { return _selectedCrew; }
            set 
            { 
                _selectedCrew = value;
                OnPropertyChanged();
                LoadDetails();
            }
        }
        private License _license;
        public License SelectedLicense 
        {
            get { return _license; }
            set
            {
                _license = value;
                OnPropertyChanged();
            }
        }
        private Training _training;
        public Training SelectedTraining 
        {
            get { return _training; }
            set
            {
                _training = value;
                OnPropertyChanged();
            }
        }
        private Test _test;
        public Test SelectedTest 
        {
            get { return _test; }
            set
            {
                _test = value;
                OnPropertyChanged();
            }
        }
        private License _ownLicense;
        public License SelectedOwnLicense 
        {
            get { return _ownLicense; }
            set
            {
                _ownLicense = value;
                OnPropertyChanged();
            }
        }
        private Training _ownTraining;
        public Training SelectedOwnTraining 
        {
            get { return _ownTraining; }
            set
            {
                _ownTraining = value;
                OnPropertyChanged();
            }
        }
        private Test _ownTest;
        public Test SelectedOwnTest 
        {
            get { return _ownTest; }
            set
            {
                _ownTest = value;
                OnPropertyChanged();
            }
        }
        private ObservableCollection<CrewLicense> _crewLicenseList;
        public ObservableCollection<CrewLicense> CrewLicenseList 
        {
            get { return _crewLicenseList; }
            set
            {
                _crewLicenseList = value;
                OnPropertyChanged();
            }
        }
        private ObservableCollection<CrewTraining> _crewTrainingList;
        public ObservableCollection<CrewTraining> CrewTrainingList 
        {
            get { return _crewTrainingList; }
            set
            {
                _crewTrainingList = value;
                OnPropertyChanged();
            }
        }  
        private ObservableCollection<CrewTest> _crewTestList;
        public ObservableCollection<CrewTest> CrewTestList 
        {
            get { return _crewTestList; }
            set
            {
                _crewTestList = value;
                OnPropertyChanged();
            }
        }
        public ICommand AddAttributeCommand { get; set; }
        private DateTime _dateEarned;
        public DateTime DateEarned 
        {
            get { return _dateEarned; }
            set
            {
                _dateEarned = value;
                OnPropertyChanged();
            }
        }
        private DateTime _expirationDate;
        public DateTime ExpirationDate 
        {
            get { return _expirationDate; }
            set
            {
                _expirationDate = value;
                OnPropertyChanged();
            }
        }
        private DateTime _testDate;
        public DateTime TestDate 
        {
            get { return _testDate; }
            set
            {
                _testDate = value;
                OnPropertyChanged();
            }
        }
        private string _trainginDescription;
        public string TrainingDescription 
        {
            get { return _trainginDescription; }
            set
            {
                _trainginDescription = value;
                OnPropertyChanged();
            }
        }
        public ICommand DeleteAttributeCommand { get; set; }
        public ICommand DeleteCommand { get; set; }
        public ICommand AddCrewCommand { get; set; }
        private ObservableCollection<CrewAssignment> _crewAssignmentList;
        public ObservableCollection<CrewAssignment> CrewAssignmentList 
        {
            get { return _crewAssignmentList; }
            set
            {
                _crewAssignmentList = value;
                OnPropertyChanged();
            }
        }
        private string _name;
        public string Name 
        {
            get { return _name; }
            set
            {
                _name = value;
                OnPropertyChanged();
            }
        }
        public EmployeeViewModel()
        {
            CrewList = new ObservableCollection<Crew>();
            LicenseList = new ObservableCollection<License>();
            TrainingList = new ObservableCollection<Training>();
            TestList = new ObservableCollection<Test>();
            TotalLicenseList = new ObservableCollection<License>();
            TotalTrainingList = new ObservableCollection<Training>();
            TotalTestList = new ObservableCollection<Test>();
            CrewLicenseList = new ObservableCollection<CrewLicense>();
            CrewTrainingList = new ObservableCollection<CrewTraining>();
            CrewTestList = new ObservableCollection<CrewTest>();
            CrewAssignmentList = new ObservableCollection<CrewAssignment>();
            AddAttributeCommand = new RelayCommand(AddAttribute, CanAddAttribute);
            DeleteAttributeCommand = new RelayCommand(DeleteAttribute,CanDeleteAttribute);
            DeleteCommand = new RelayCommand(Delete, CanDelete);
            AddCrewCommand = new RelayCommand(AddCrew, CanAddCrew);
            Crew();
            LoadSkills();
        }

        private bool CanAddCrew(object obj)
        {
            return true;
        }

        private void AddCrew(object obj)
        {
            var confirm = MessageBox.Show(
                 "Are you sure you want to proceed?",
                 "Confirm Action",
                 MessageBoxButton.YesNo,
                 MessageBoxImage.Question
             );
            if (confirm == MessageBoxResult.Yes)
            {
                using var context = new CharterContext();

                var addedCrew = new Crew
                {
                    CrewName = Name
                };

                context.Crew.Add(addedCrew);
                context.SaveChanges();
            }
        }

        private bool CanDelete(object obj)
        {
            return true;
        }

        private void Delete(object obj)
        {
            var confirm = MessageBox.Show(
                 "Are you sure you want to proceed?",
                 "Confirm Action",
                 MessageBoxButton.YesNo,
                 MessageBoxImage.Question
             );
            if (confirm == MessageBoxResult.Yes)
            {
                using var context = new CharterContext();

                var crew = context.Crew.FirstOrDefault(c => c.CrewId == SelectedCrew.CrewId);
                if (crew == null) return;
                var linkedLicenses = context.CrewLicense
                    .Where(c => c.CrewId == SelectedCrew.CrewId)
                    .ToList();
                var linkedTraining = context.CrewTraining
                    .Where(c => c.CrewId == SelectedCrew.CrewId)
                    .ToList();
                var linkedTest = context.CrewTest
                    .Where(c => c.CrewId == SelectedCrew.CrewId)
                    .ToList();
                var crewAssignment = context.CrewAssignment
                    .Where(c => c.CrewId == SelectedCrew.CrewId)
                    .ToList();

                context.CrewLicense.RemoveRange(linkedLicenses);
                context.CrewTraining.RemoveRange(linkedTraining);
                context.CrewTest.RemoveRange(linkedTest);
                context.CrewAssignment.RemoveRange(crewAssignment);
                context.Crew.Remove(crew);
                context.SaveChanges();
                foreach(var item in linkedLicenses)
                {
                    CrewLicenseList.Remove(item);
                }
                foreach(var item in linkedTraining)
                {
                    CrewTrainingList.Remove(item);
                }
                foreach(var item in linkedTest)
                {
                    CrewTestList.Remove(item);
                }
                foreach(var item in crewAssignment)
                {
                    CrewAssignmentList.Remove(item);
                }
                CrewList.Remove(SelectedCrew);
            }
        }

        private bool CanDeleteAttribute(object obj)
        {
            return true;
        }

        private void DeleteAttribute(object obj)
        {
            var confirm = MessageBox.Show(
                 "Are you sure you want to proceed?",
                 "Confirm Action",
                 MessageBoxButton.YesNo,
                 MessageBoxImage.Question
             );
            if (confirm == MessageBoxResult.Yes)
            {
                using var context = new CharterContext();
                if((SelectedOwnLicense == null && SelectedOwnTraining == null && SelectedOwnTest == null) || SelectedCrew == null)
                {
                    MessageBox.Show("Please select an attribute and a customer");
                    return;
                }
                if(SelectedOwnLicense != null)
                {
                    var ownlicense = context.CrewLicense.FirstOrDefault(c => c.LicenseId == SelectedOwnLicense.LicenseId);
                    if (ownlicense == null) return;
                    context.CrewLicense.Remove(ownlicense);
                    context.SaveChanges();
                    LicenseList.Remove(SelectedOwnLicense);
                }
                if(SelectedOwnTraining != null)
                {
                    var owntraining = context.CrewTraining.FirstOrDefault(c => c.TrainingId == SelectedOwnTraining.TrainingId);
                    if (owntraining == null) return;
                    context.CrewTraining.Remove(owntraining);
                    context.SaveChanges();
                    TrainingList.Remove(SelectedOwnTraining);
                }
                if(SelectedOwnTest != null)
                {
                    var owntest = context.CrewTest.FirstOrDefault(c => c.TestId == SelectedOwnTest.TestId);
                    if (owntest == null) return;
                    context.CrewTest.Remove(owntest);
                    context.SaveChanges();
                    TestList.Remove(SelectedOwnTest);
                }
            }
        }

        private bool CanAddAttribute(object obj)
        {
            return true;
        }

        private void AddAttribute(object obj)
        {
            var confirm = MessageBox.Show(
                "Are you sure you want to proceed?",
                "Confirm Action",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question
            );
            if(confirm == MessageBoxResult.Yes)
            {
                using var context = new CharterContext();
                if (SelectedCrew == null) return;
                if (SelectedLicense != null)
                {
                    bool exists = context.CrewLicense.Any(x =>
                        x.CrewId == SelectedCrew.CrewId &&
                        x.LicenseId == SelectedLicense.LicenseId);
                    var crewLicense = new CrewLicense
                    {
                        LicenseId = SelectedLicense.LicenseId,
                        CrewId = SelectedCrew.CrewId,
                        DateEarned = DateEarned,
                        ExpirationDate = ExpirationDate
                    };
                    if(!exists) context.CrewLicense.Add(crewLicense);
                    else MessageBox.Show("This license is already assigned to the crew.");
                    SelectedLicense = null;
                }
                if (SelectedTraining != null)
                {
                    if (TrainingDescription == null) MessageBox.Show("Please place description");
                    else
                    {
                        var crewTraining = new CrewTraining
                        {
                            TrainingId = SelectedTraining.TrainingId,
                            CrewId = SelectedCrew.CrewId,
                            TrainingDescription = TrainingDescription
                        };
                        bool exists = context.CrewTraining.Any(x =>
                            x.CrewId == SelectedCrew.CrewId &&
                            x.TrainingId == SelectedTraining.TrainingId);
                        if (!exists) context.CrewTraining.Add(crewTraining);
                        else MessageBox.Show("This license is already assigned to the crew.");
                        SelectedTraining = null;
                    }
                }
                if (SelectedTest != null)
                {
                    var crewTest = new CrewTest
                    {
                        TestId = SelectedTest.TestId,
                        CrewId = SelectedCrew.CrewId,
                        TestDate = TestDate,
                        IsPassed = true
                    };
                    bool exists = context.CrewTest.Any(x =>
                        x.CrewId == SelectedCrew.CrewId &&
                        x.TestId == SelectedTest.TestId);
                   if(!exists) context.CrewTest.Add(crewTest);
                   else MessageBox.Show("This license is already assigned to the crew.");
                   SelectedTest = null;
                }
                context.SaveChanges();
            }
        }
        private void LoadSkills()
        {
            using var context = new CharterContext();

            var licenses = context.License.ToList();
            var trainings = context.Training.ToList();
            var tests = context.Test.ToList();

            foreach(var l in licenses)
            {
                TotalLicenseList.Add(l);
            }
            foreach(var tr in trainings)
            {
                TotalTrainingList.Add(tr);
            }
            foreach(var t in tests)
            {
                TotalTestList.Add(t);
            }
        }
        private void Crew()
        {
            using var context = new CharterContext();

            var result = context.Crew
                .Include(c => c.CrewLicenseList)
                    .ThenInclude(c => c.LicenseLink)
                .Include(c => c.CrewTrainingList)
                    .ThenInclude(c => c.TrainingLink)
                .Include(c => c.CrewTestList)
                    .ThenInclude(c => c.TestLink)
                .ToList();

            foreach (var item in result)
            {
                CrewList.Add(item);
            }
        }
        private void LoadDetails()
        {
            LicenseList.Clear();
            TrainingList.Clear();
            TestList.Clear();
            using var context = new CharterContext();
            if (SelectedCrew != null)
            {
                var license = context.CrewLicense
                    .Where(c => c.CrewId == SelectedCrew.CrewId)
                    .Select(c => c.LicenseLink)
                    .ToList();

                foreach (var item in license)
                {
                    LicenseList.Add(item);
                }

                var training = context.CrewTraining
                    .Where(c => c.CrewId == SelectedCrew.CrewId)
                    .Select(c => c.TrainingLink)
                    .ToList();

                foreach (var item in training)
                {
                    TrainingList.Add(item);
                }

                var test = context.CrewTest
                    .Where(c => c.CrewId == SelectedCrew.CrewId)
                    .Select(c => c.TestLink)
                    .ToList();

                foreach (var item in test)
                {
                    TestList.Add(item);
                }
            }
        }
    }
}
