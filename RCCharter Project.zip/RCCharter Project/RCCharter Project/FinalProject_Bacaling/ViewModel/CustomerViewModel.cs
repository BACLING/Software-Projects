﻿using FinalProject_Bacaling.Command;
using System.Collections.ObjectModel;
using RCCharterDb;
using System.Windows.Input;
using System.Windows;
using Microsoft.EntityFrameworkCore;

namespace FinalProject_Bacaling.ViewModel
{
    public class CustomerViewModel : NotifyPropertyChanged
    {
        private Customer _edit;
        public Customer EditCustomer
        {
            get { return _edit; }
            set
            {
                _edit = value;
                OnPropertyChanged();
            }
        }
        private Customer _customer;
        public Customer SelectedCustomer
        {
            get { return _customer; }
            set
            {
                _customer = value;
                OnPropertyChanged();
                if (_customer != null)
                {
                    if (SelectedCustomer.HasCreditAuthorization == true)
                    {
                        EditCustomer = new Customer
                        {
                            CustomerName = _customer.CustomerName,
                            HasCreditAuthorization = _customer.HasCreditAuthorization,
                            AccountLink = new Account
                            {
                                AccountBalance = _customer.AccountLink.AccountBalance,
                                PartialPayable = _customer.AccountLink.PartialPayable
                            }
                        };
                    }
                    else
                    {
                        EditCustomer = new Customer
                        {
                            CustomerName = _customer.CustomerName,
                            HasCreditAuthorization = _customer.HasCreditAuthorization
                        };
                    }
                }
            }
        }
        private ObservableCollection<Customer> _customerList;
        public ObservableCollection<Customer> CustomerList
        {
            get { return _customerList; }
            set 
            { _customerList = value; 
                OnPropertyChanged(nameof(CustomerList)); 
            }
        }
        public ICommand SaveCommand { get; set; }
        public ICommand CancelCommand { get; set; }
        public ICommand DeleteCustomer { get; set; }
        public ObservableCollection<bool> AuthorizationList { get; set; }

        public CustomerViewModel()
        {
            CustomerList = new ObservableCollection<Customer>();
            DeleteCustomer = new RelayCommand(Delete, CanDelete);
            AuthorizationList = new ObservableCollection<bool> { true, false };
            SaveCommand = new RelayCommand(Save, CanSave);
            CancelCommand = new RelayCommand(Cancel, CanCancel);
            Customers();
        }

        private bool CanCancel(object obj)
        {
            return true;
        }

        private void Cancel(object obj)
        {
            var confirm = MessageBox.Show(
                "Are you sure you want to proceed?",
                "Confirm Action",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question
                );

            if (confirm != MessageBoxResult.Yes) return;
            if (SelectedCustomer == null) return;

            EditCustomer = new Customer
            {
                CustomerId = SelectedCustomer.CustomerId,
                CustomerName = SelectedCustomer.CustomerName,
                HasCreditAuthorization = SelectedCustomer.HasCreditAuthorization,
            };
        }

        private bool CanSave(object obj)
        {
            return true;
        }

        private void Save(object obj)
        {
            
            var confirm = MessageBox.Show(
                "Are you sure you want to proceed?",
                "Confirm Action",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question
            );
            if (confirm == MessageBoxResult.Yes)
            {
                using var context = new CharterContext();
                var customer = context.Customer
                    .Include(c => c.AccountLink)
                    .FirstOrDefault(c => c.CustomerId == SelectedCustomer.CustomerId);
                if (customer != null)
                {
                    customer.CustomerName = EditCustomer.CustomerName;
                    customer.HasCreditAuthorization = EditCustomer.HasCreditAuthorization;

                    if (customer.HasCreditAuthorization)
                    {
                        customer.AccountLink.AccountBalance = EditCustomer.AccountLink.AccountBalance;
                        customer.AccountLink.PartialPayable = EditCustomer.AccountLink.PartialPayable;
                        SelectedCustomer.AccountLink.AccountBalance = EditCustomer.AccountLink.AccountBalance;
                        SelectedCustomer.AccountLink.PartialPayable = EditCustomer.AccountLink.PartialPayable;
                    }

                    context.SaveChanges();

                    SelectedCustomer.CustomerName = EditCustomer.CustomerName;
                    SelectedCustomer.HasCreditAuthorization = EditCustomer.HasCreditAuthorization;
                    
                }
            }
        }
        private bool CanDelete(object obj)
        {
            return true;
        }

        private void Delete(object obj)
        {
            var confirm = MessageBox.Show("Are you sure you want to proceed?",
                "Confirm Action",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question
                );
            if(confirm == MessageBoxResult.Yes)
            {
                using var context = new CharterContext();
                if (SelectedCustomer != null)
                {
                    if (SelectedCustomer.HasCreditAuthorization)
                    {
                        var accounts = context.Account
                            .Where(a => a.CustomerId == SelectedCustomer.CustomerId)
                            .ToList();
                        foreach (var account in accounts)
                        {
                            var billings = context.Billing
                                .Where(b => b.AccountId == account.AccountId)
                                .ToList();
                            context.Billing.RemoveRange(billings);
                        }
                        context.Account.RemoveRange(accounts);
                    }
                    context.Customer.Remove(SelectedCustomer);
                    CustomerList.Remove(SelectedCustomer);
                    context.SaveChanges();
                }
            }
        }

        private void Customers()
        {
            using var context = new CharterContext();

            var result = context.Customer
                .Include(c => c.AccountLink)
                .ToList();

            foreach(var customer in result)
            {
                CustomerList.Add(customer);
            }
        }
    }
}
