﻿using FinalProject_Bacaling.Command;

namespace FinalProject_Bacaling.ViewModel
{
    public class MainViewModel : NotifyPropertyChanged
    {

        public MainViewModel()
        {
            
        }

    }
}
