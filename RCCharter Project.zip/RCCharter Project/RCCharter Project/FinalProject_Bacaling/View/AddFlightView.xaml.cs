﻿using System.Windows.Controls;
using FinalProject_Bacaling.ViewModel;
namespace FinalProject_Bacaling.View
{
    /// <summary>
    /// Interaction logic for AddFlightView.xaml
    /// </summary>
    public partial class AddFlightView : UserControl
    {
        public AddFlightView()
        {
            InitializeComponent();
            DataContext = new FlightBillingViewModel();
        }
    }
}
