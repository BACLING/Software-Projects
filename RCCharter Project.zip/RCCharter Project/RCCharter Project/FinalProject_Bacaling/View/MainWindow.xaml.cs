﻿using FinalProject_Bacaling.ViewModel;
using System.Windows;

namespace FinalProject_Bacaling
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            DataContext = new MainViewModel();
        }
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
           
        }
    }
}