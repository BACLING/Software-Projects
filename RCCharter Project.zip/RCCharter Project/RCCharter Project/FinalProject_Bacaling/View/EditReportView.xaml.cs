﻿using RCCharterDb;
using System.Windows.Controls;

namespace FinalProject_Bacaling.View
{
    /// <summary>
    /// Interaction logic for EditReportView.xaml
    /// </summary>
    public partial class EditReportView : UserControl
    {
        public EditReportView()
        {
            InitializeComponent();
        }

        private void Textbox_TextChanged(object sender, TextChangedEventArgs e)
        {
            Reports.Items.Filter = FilterMethod;
        }
        private bool FilterMethod(object obj)
        {
            MonthlyReport item = (MonthlyReport)obj;
            if(item == null) return false;
            return item.MonthlyReportId.ToString().Contains(Textbox.Text, StringComparison.OrdinalIgnoreCase);
        }
    }
}
