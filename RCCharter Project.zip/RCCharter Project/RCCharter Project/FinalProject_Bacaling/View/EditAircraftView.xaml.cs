﻿using System.Windows.Controls;
namespace FinalProject_Bacaling.View
{
    /// <summary>
    /// Interaction logic for EditAircraftView.xaml
    /// </summary>
    public partial class EditAircraftView : UserControl
    {
        public EditAircraftView()
        {
            InitializeComponent();
        }
    }
}
