﻿using System.Windows.Controls;
using FinalProject_Bacaling.ViewModel;

namespace FinalProject_Bacaling.View
{
    /// <summary>
    /// Interaction logic for ReportView.xaml
    /// </summary>
    public partial class ReportView : UserControl
    {
        public ReportView()
        {
            InitializeComponent();
            DataContext = new ReportViewModel();
        }
    }
}
