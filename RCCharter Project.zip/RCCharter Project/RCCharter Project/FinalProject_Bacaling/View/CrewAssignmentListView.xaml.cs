﻿using RCCharterDb;
using System.Windows.Controls;

namespace FinalProject_Bacaling.View
{
    /// <summary>
    /// Interaction logic for CrewAssignmentListView.xaml
    /// </summary>
    public partial class CrewAssignmentListView : UserControl
    {
        public CrewAssignmentListView()
        {
            InitializeComponent();
            
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            FlightCrews.Items.Filter = FilterMethod;
        }
        private bool FilterMethod(object obj)
        {
            CrewAssignment cus = (CrewAssignment)obj;
            if (cus == null) return false;
            return cus.FlightCrewId.ToString().Contains(TextBox.Text, StringComparison.OrdinalIgnoreCase) 
                || cus.CrewLink.CrewName.Contains(TextBox.Text, StringComparison.OrdinalIgnoreCase)
                || cus.FlightLink.FlightDate.ToString().Contains(TextBox.Text, StringComparison.OrdinalIgnoreCase)
                || cus.AircraftLink.Model.Contains(TextBox.Text, StringComparison.OrdinalIgnoreCase)
                ;
        }
    }
}
