﻿using System.Windows.Controls;
using FinalProject_Bacaling.ViewModel;
namespace FinalProject_Bacaling.View
{
    /// <summary>
    /// Interaction logic for AddReservationView.xaml
    /// </summary>
    public partial class AddReservationView : UserControl
    {
        public AddReservationView()
        {
            InitializeComponent();
            DataContext = new ReservationViewModel();
        }
    }
}
