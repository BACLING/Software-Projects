﻿using System.Windows.Controls;

namespace FinalProject_Bacaling.View
{
    /// <summary>
    /// Interaction logic for AddReportView.xaml
    /// </summary>
    public partial class AddReportView : UserControl
    {
        public AddReportView()
        {
            InitializeComponent();
        }
    }
}
