﻿using System.Windows.Controls;
using FinalProject_Bacaling.ViewModel;
using RCCharterDb;
namespace FinalProject_Bacaling.View
{
    /// <summary>
    /// Interaction logic for EmployeeView.xaml
    /// </summary>
    public partial class EmployeeView : UserControl
    {
        public EmployeeView()
        {
            InitializeComponent();
            DataContext = new EmployeeViewModel();
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            EmployeeList.Items.Filter = FilterMethod;
        }
        private bool FilterMethod(object obj)
        {
            Crew emp = (Crew)obj;
            if (emp == null) return false;
            return emp.CrewId.ToString().Contains(TextBox.Text, StringComparison.OrdinalIgnoreCase) || emp.CrewName.Contains(TextBox.Text, StringComparison.OrdinalIgnoreCase);
        }
    }
}
