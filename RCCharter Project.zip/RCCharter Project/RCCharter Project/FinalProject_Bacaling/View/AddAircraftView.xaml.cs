﻿using System.Windows.Controls;
using FinalProject_Bacaling.ViewModel;
namespace FinalProject_Bacaling.View
{
    /// <summary>
    /// Interaction logic for AddAircraftView.xaml
    /// </summary>
    public partial class AddAircraftView : UserControl
    {
        public AddAircraftView()
        {
            InitializeComponent();
            DataContext = new ReservationViewModel();
        }
    }
}
