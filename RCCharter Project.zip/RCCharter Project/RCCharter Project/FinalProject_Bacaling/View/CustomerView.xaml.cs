﻿using System.Windows.Controls;
using FinalProject_Bacaling.ViewModel;
using RCCharterDb;

namespace FinalProject_Bacaling.View
{
    /// <summary>
    /// Interaction logic for CustomerView.xaml
    /// </summary>
    public partial class CustomerView : UserControl
    {
        public CustomerView()
        {
            InitializeComponent();
            DataContext = new CustomerViewModel();
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            CustomerList.Items.Filter = FilterMethod;
        }
        private bool FilterMethod(object obj)
        {
            Customer cus = (Customer)obj;
            if (cus == null) return false;
            return cus.CustomerId.ToString().Contains(TextBox.Text, StringComparison.OrdinalIgnoreCase) || cus.CustomerName.Contains(TextBox.Text, StringComparison.OrdinalIgnoreCase);

        }
    }
}
