﻿using System.Windows.Controls;
using RCCharterDb;

namespace FinalProject_Bacaling.View
{
    /// <summary>
    /// Interaction logic for EmployeeDetailsView.xaml
    /// </summary>
    public partial class EmployeeDetailsView : UserControl
    {
        public EmployeeDetailsView()
        {
            InitializeComponent();
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            LicenseList.Items.Filter = FilterMethod1;
        }

        private void TrainingSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            TrainingList.Items.Filter = FilterMethod2;
        }

        private void TestSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            TestList.Items.Filter = FilterMethod3;
        }
        private bool FilterMethod1(object obj)
        {
            License item = (License)obj;
            if (item == null) return false;
            return item.LicenseId.ToString().Contains(LicenseSearch.Text, StringComparison.OrdinalIgnoreCase) || item.LicenseDescription.Contains(LicenseSearch.Text, StringComparison.OrdinalIgnoreCase);
        }
        private bool FilterMethod2(object obj)
        {
            Training item = (Training)obj;
            if (item == null) return false;
            return item.TrainingId.ToString().Contains(TrainingSearch.Text, StringComparison.OrdinalIgnoreCase) || item.TrainingDescription.Contains(TrainingSearch.Text, StringComparison.OrdinalIgnoreCase);
        }
        private bool FilterMethod3(object obj)
        {
            Test item = (Test)obj;
            if (item == null) return false;
            return item.TestId.ToString().Contains(TestSearch.Text, StringComparison.OrdinalIgnoreCase) || item.TestDescription.Contains(TestSearch.Text, StringComparison.OrdinalIgnoreCase);
        }
    }
}
