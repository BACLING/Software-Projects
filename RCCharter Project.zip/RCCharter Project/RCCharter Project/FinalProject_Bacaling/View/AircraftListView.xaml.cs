﻿using System.Windows.Controls;
using FinalProject_Bacaling.ViewModel;
using RCCharterDb;
namespace FinalProject_Bacaling.View
{
    /// <summary>
    /// Interaction logic for AircraftListView.xaml
    /// </summary>
    public partial class AircraftListView : UserControl
    {
        public AircraftListView()
        {
            InitializeComponent();
            DataContext = new ReservationViewModel();
        }

        private void Textbox_TextChanged(object sender, TextChangedEventArgs e)
        {
            Aircrafts.Items.Filter = FilterMethod;
        }
        private bool FilterMethod(object obj)
        {
            Aircraft air = (Aircraft)obj;
            if(air == null) return false;
            return air.AircraftId.ToString().Contains(Textbox.Text, StringComparison.OrdinalIgnoreCase) || air.Model.Contains(Textbox.Text, StringComparison.OrdinalIgnoreCase);
        }
    }
}
