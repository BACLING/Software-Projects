﻿using System.Windows.Controls;
using FinalProject_Bacaling.ViewModel;
using RCCharterDb;
namespace FinalProject_Bacaling.View
{
    /// <summary>
    /// Interaction logic for Reservations.xaml
    /// </summary>
    public partial class Reservations : UserControl
    {
        public Reservations()
        {
            InitializeComponent();
            DataContext = new ReservationViewModel();
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            Reservation.Items.Filter = FilterMethod;
        }
        private bool FilterMethod(object obj)
        {
            Reservation res = (Reservation)obj;
            if (res == null) return false;
            return res.ReservationId.ToString().Contains(TextBox.Text, StringComparison.OrdinalIgnoreCase) || res.Destination.Contains(TextBox.Text, StringComparison.OrdinalIgnoreCase);

        }
    }
}
