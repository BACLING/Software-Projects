﻿using FinalProject_Bacaling.ViewModel;
using System.Windows.Controls;

namespace FinalProject_Bacaling.View
{
    /// <summary>
    /// Interaction logic for FlightCrewView.xaml
    /// </summary>
    public partial class FlightCrewView : UserControl
    {
        public FlightCrewView()
        {
            InitializeComponent();
            DataContext = new FlightBillingViewModel();
        }
    }
}
