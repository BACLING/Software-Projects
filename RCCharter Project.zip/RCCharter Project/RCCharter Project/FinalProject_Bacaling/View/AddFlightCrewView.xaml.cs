﻿using System.Windows.Controls;

namespace FinalProject_Bacaling.View
{
    /// <summary>
    /// Interaction logic for AddFlightCrewView.xaml
    /// </summary>
    public partial class AddFlightCrewView : UserControl
    {
        public AddFlightCrewView()
        {
            InitializeComponent();
        }
    }
}
