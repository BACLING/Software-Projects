﻿using System.Windows.Controls;

namespace FinalProject_Bacaling.View
{
    /// <summary>
    /// Interaction logic for EditCustomerView.xaml
    /// </summary>
    public partial class EditCustomerView : UserControl
    {
        public EditCustomerView()
        {
            InitializeComponent();
        }
    }
}
