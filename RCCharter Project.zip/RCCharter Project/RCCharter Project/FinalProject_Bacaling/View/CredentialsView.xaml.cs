﻿using FinalProject_Bacaling.ViewModel;
using System.Windows.Controls;

namespace FinalProject_Bacaling.View
{
    /// <summary>
    /// Interaction logic for CredentialsView.xaml
    /// </summary>
    public partial class CredentialsView : UserControl
    {
        public CredentialsView()
        {
            InitializeComponent();
            DataContext = new CredentialViewModel();
        }
    }
}
