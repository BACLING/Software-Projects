﻿using System.Windows.Controls;
using FinalProject_Bacaling.ViewModel;
namespace FinalProject_Bacaling.View
{
    /// <summary>
    /// Interaction logic for AddCustomerView.xaml
    /// </summary>
    public partial class AddCustomerView : UserControl
    {
        public AddCustomerView()
        {
            InitializeComponent();
            DataContext = new AddCustomerViewModel();
        }
    }
}
