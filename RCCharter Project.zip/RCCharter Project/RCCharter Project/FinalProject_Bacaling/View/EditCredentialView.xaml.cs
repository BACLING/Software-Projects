﻿using RCCharterDb;
using System.Windows.Controls;

namespace FinalProject_Bacaling.View
{
    /// <summary>
    /// Interaction logic for EditCredentialView.xaml
    /// </summary>
    public partial class EditCredentialView : UserControl
    {
        public EditCredentialView()
        {
            InitializeComponent();
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            LicenseList.Items.Filter = FilterMethod1;
        }

        private void TextBox_TextChanged_1(object sender, TextChangedEventArgs e)
        {
            TrainingList.Items.Filter = FilterMethod2;
        }

        private void TextBox_TextChanged_2(object sender, TextChangedEventArgs e)
        {
            TestList.Items.Filter = FilterMethod3;
        }
        private bool FilterMethod1(object obj)
        {
            License item = (License)obj;
            if (item == null) return false;
            return item.LicenseId.ToString().Contains(LicenseSearch.Text, StringComparison.OrdinalIgnoreCase) || item.LicenseDescription.Contains(LicenseSearch.Text, StringComparison.OrdinalIgnoreCase);
        }
        private bool FilterMethod2(object obj)
        {
            Training item = (Training)obj;
            if (item == null) return false;
            return item.TrainingId.ToString().Contains(TrainingSearch.Text, StringComparison.OrdinalIgnoreCase) || item.TrainingDescription.Contains(TrainingSearch.Text, StringComparison.OrdinalIgnoreCase);
        }
        private bool FilterMethod3(object obj)
        {
            Test item = (Test)obj;
            if (item == null) return false;
            return item.TestId.ToString().Contains(TestSearch.Text, StringComparison.OrdinalIgnoreCase) || item.TestDescription.Contains(TestSearch.Text, StringComparison.OrdinalIgnoreCase);
        }
    }
}
