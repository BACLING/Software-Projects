﻿using System.Windows.Controls;
using FinalProject_Bacaling.ViewModel;
using RCCharterDb;


namespace FinalProject_Bacaling.View
{
    /// <summary>
    /// Interaction logic for FlightBillingView.xaml
    /// </summary>
    public partial class FlightBillingView : UserControl
    {
        public FlightBillingView()
        {
            InitializeComponent();
            DataContext = new FlightBillingViewModel();
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            Flights.Items.Filter = FilterMethod;
        }
        private bool FilterMethod(object obj)
        {
            CharterFlight cus = (CharterFlight)obj;
            if (cus == null) return false;
            return cus.CharterFlightId.ToString().Contains(TextBox.Text, StringComparison.OrdinalIgnoreCase) || cus.FlightDate.ToString().Contains(TextBox.Text, StringComparison.OrdinalIgnoreCase);

        }
    }
}
