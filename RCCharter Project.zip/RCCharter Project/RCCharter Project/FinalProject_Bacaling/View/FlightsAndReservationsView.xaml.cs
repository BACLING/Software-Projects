﻿using System.Windows.Controls;

namespace FinalProject_Bacaling.View
{
    /// <summary>
    /// Interaction logic for FlightsAndReservationsView.xaml
    /// </summary>
    public partial class FlightsAndReservationsView : UserControl
    {
        public FlightsAndReservationsView()
        {
            InitializeComponent();
        }
    }
}
